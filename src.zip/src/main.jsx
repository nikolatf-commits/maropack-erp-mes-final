import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './pro-ui.css'
import './styles/maropack-phase2.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
