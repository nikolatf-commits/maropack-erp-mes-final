// ─────────────────────────────────────────────────────────────────────────────
//  MAROPACK — GanttPlanPRO  [v1]
//  Kalendar mašina: pretvara plan (red čekanja po mašini) u DATUME.
//
//  Režim rada: 2 smene = 960 min/dan (06–22h), pon–pet, vikend se preskače.
//  Vreme naloga: ručno trajanje → setup + metri ÷ brzina → fallback.
//  ZAVISNOSTI: operacija ne počinje pre završetka prethodne operacije ISTOG
//  naloga (ma na kojoj mašini bila) — a nalozi bez čekanja "uskaču u rupu".
//  Datumi se NIGDE ne čuvaju: uvek se izračunaju iz plana → svako prevlačenje,
//  promena redosleda ili brzine mašine odmah pomera sve trake (live).
//
//  Renderuje ga MachineSchedulerPRO kao tab "Kalendar" (isti podaci i drag/drop).
// ─────────────────────────────────────────────────────────────────────────────
import React, { useEffect, useMemo, useState } from "react";
import { procenaMinNaMasini, REDOSLED_OPERACIJA, jeGotov, jeGotovZaSledecu, jeStiglo, jePoslato, canonRef, OP_LABELE } from "../utils/nalogMetrika.js";

import { radnoSada, izracunajRaspored, jeRadni, kapacitetDana, DAN_MIN, DAN_OD, dateToWm, wmToDate } from "../utils/planRaspored.js";

// Boje operacija (UI).
const OP_BOJA = { stampa: "#2563eb", lakiranje: "#7c3aed", kasiranje: "#0891b2", rezanje: "#dc2626", formatiranje: "#ea580c", kese: "#16a34a", spulne: "#9333ea", ostalo: "#64748b" };

// ── PRIKAZ ───────────────────────────────────────────────────────────────────
// Radna nedelja pon–SUB puni ekran; klizač na dnu vodi u sledeće nedelje (6 unapred).
// Širina dana se računa iz širine kontejnera; strelice ‹ › listaju nedelje.
const IME_PX = 210, RED_PX = 134;

export default function GanttPlanPRO({ machines, plan, orderMap, opStatusi, dragStart, dropToMachine }) {
    const [nedelja, setNedelja] = useState(0); // pomeranje pogleda po nedeljama
    const [prikaz, setPrikaz] = useState('nedelja'); // 'nedelja' | 'dan'
    const [danPomak, setDanPomak] = useState(0);     // pomeranje po danima (dnevni prikaz)
    const [prikaziPrazne, setPrikaziPrazne] = useState(false); // prazne mašine samo na zahtev
    const [grupa, setGrupa] = useState('sve');
    // širina dana = (širina kontejnera − kolona imena) ÷ 5 radnih dana; prati resize
    const wrapRef = React.useRef(null);
    const [sirina, setSirina] = useState(1100);
    useEffect(() => {
        const meri = () => { if (wrapRef.current) setSirina(wrapRef.current.clientWidth); };
        meri(); window.addEventListener('resize', meri); return () => window.removeEventListener('resize', meri);
    }, []);
    const DAN_PX = Math.max(140, Math.floor((sirina - IME_PX) / 6)); // pon–sub (6 dana) pune širine
    const DAN_PX_JEDAN = Math.max(640, sirina - IME_PX - 4);         // dnevni prikaz: jedan dan preko cele širine
    const jeDan = prikaz === 'dan';
    const VIK_PX = 0;      // nedelja se ne prikazuje; subota JESTE radna (1 smena)
    const NEDELJA = 1;
    // "sada" se osvežava na minut — bez ovoga bi kalendar ostao usidren u trenutak
    // otvaranja ekrana, pa bi posle sat vremena svi startovi bili u prošlosti.
    const [minut, setMinut] = useState(0);
    useEffect(() => { const t = setInterval(() => setMinut((x) => x + 1), 60000); return () => clearInterval(t); }, []);
    const sidro = useMemo(() => radnoSada(), [minut]);

    const raspored = useMemo(
        () => izracunajRaspored({ machines, plan, orderMap, opStatusi, sidro }),
        [machines, plan, orderMap, opStatusi, sidro]
    );

    // vidljivi opseg: ponedeljak tekuće nedelje + offset, NEDELJA nedelja (default 1)
    const dani = useMemo(() => {
        // DNEVNI prikaz: jedna kolona = izabrani dan, razvučen preko cele širine (kolone su sati)
        if (jeDan) {
            const dd = new Date(sidro); dd.setDate(dd.getDate() + danPomak); dd.setHours(6, 0, 0, 0);
            return { lista: [{ datum: dd, x: IME_PX, w: DAN_PX_JEDAN, subota: dd.getDay() === 6 }], ukupno: IME_PX + DAN_PX_JEDAN };
        }
        const start = new Date(sidro);
        start.setDate(start.getDate() - ((start.getDay() + 6) % 7) + nedelja * 7);
        start.setHours(6, 0, 0, 0);
        const out = []; let x = IME_PX; const d = new Date(start);
        // 6 nedelja unapred: prva staje na ekran, ostale se dohvataju klizačem na dnu
        for (let i = 0; i < 6 * 7; i++) {
            if (jeRadni(d)) { out.push({ datum: new Date(d), x, w: DAN_PX, subota: d.getDay() === 6 }); x += DAN_PX; }
            d.setDate(d.getDate() + 1);
        }
        return { lista: out, ukupno: x };
    }, [sidro, nedelja, DAN_PX, jeDan, danPomak, DAN_PX_JEDAN]);

    // dnevni prikaz: granice izabranog dana + satne linije (06:00 → kraj smene)
    const danBounds = useMemo(() => {
        if (!jeDan || !dani.lista.length) return null;
        const c = dani.lista[0];
        const s = new Date(c.datum); s.setHours(6, 0, 0, 0);
        const cap = kapacitetDana(c.datum) || DAN_MIN;
        const e = new Date(c.datum); e.setHours(0, 0, 0, 0); e.setMinutes(DAN_OD + cap);
        return { s, e, cap };
    }, [jeDan, dani]);
    const satiRuler = useMemo(() => {
        if (!jeDan || !dani.lista.length) return [];
        const c = dani.lista[0];
        const cap = kapacitetDana(c.datum) || DAN_MIN;
        const arr = [];
        for (let mm = 0; mm <= cap; mm += 60) {
            arr.push({ x: c.x + (mm / cap) * c.w, label: String(6 + mm / 60).padStart(2, '0') + ':00' });
        }
        return arr;
    }, [jeDan, dani]);

    const xOd = (dat) => {
        for (const c of dani.lista) {
            const od = new Date(c.datum); od.setHours(6, 0, 0, 0);
            const cap = kapacitetDana(c.datum) || DAN_MIN;
            const doD = new Date(c.datum); doD.setHours(0, 0, 0, 0); doD.setMinutes(DAN_OD + cap);
            if (dat < od) return c.x;
            if (dat <= doD) return c.x + Math.min(1, Math.max(0, (dat - od) / (cap * 60000))) * c.w;
        }
        return dani.ukupno;
    };

    const danas = new Date(); danas.setHours(0, 0, 0, 0);
    const fmtD = (d) => d.toLocaleDateString("sr-RS", { weekday: "short", day: "numeric", month: "numeric" });
    const fmtT = (d) => fmtD(d) + " ~" + d.toLocaleTimeString("sr-RS", { hour: "2-digit", minute: "2-digit" });

    // zauzetost po mašini po danu
    const zauzetost = useMemo(() => {
        const z = {};
        raspored.forEach((s) => {
            if (s.eksterno) return;
            let a = dateToWm(sidro, s.start), b = dateToWm(sidro, s.end);
            // hodaj po radnim danima od starta do kraja i sabiraj minute po danu
            let wm = a;
            while (wm < b) {
                const danStart = wmToDate(sidro, wm);
                const cap = kapacitetDana(danStart) || DAN_MIN;
                const dan0 = new Date(danStart); dan0.setHours(0, 0, 0, 0);
                // koliko wm-minuta ostaje do kraja tog radnog dana
                const minuloDanas = (danStart.getHours() * 60 + danStart.getMinutes()) - DAN_OD;
                const doKrajaDana = Math.max(0, cap - minuloDanas);
                const uzmi = Math.min(doKrajaDana, b - wm);
                const k = s.masinaId + "|" + dan0.getTime();
                z[k] = (z[k] || 0) + uzmi;
                wm += uzmi > 0 ? uzmi : 1;
            }
        });
        return z;
    }, [raspored, sidro]);

    const probijaUk = raspored.filter((s) => s.probija).length;
    const zauzeteId = useMemo(() => new Set(raspored.map((s) => s.masinaId)), [raspored]);
    const vidljive = machines.filter((m) =>
        (grupa === 'sve' || m.type === grupa) && (prikaziPrazne || zauzeteId.has(m.id)));
    const kartica = { background: "#fff", border: "1px solid #e2e8f0", borderRadius: 16, boxShadow: "0 10px 30px rgba(15,23,42,.06)" };
    const chip = { background: "#fff", border: "1px solid #e2e8f0", borderRadius: 999, padding: "6px 12px", fontWeight: 800, fontSize: 12.5 };

    return (
        <div>
            <div style={{ ...kartica, padding: 12, marginBottom: 14, display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
                <span style={chip}>U planu: <b style={{ color: "#1d4ed8" }}>{raspored.length}</b></span>
                <span style={{ ...chip, ...(probijaUk ? { borderColor: "#fecaca", background: "#fef2f2", color: "#b91c1c" } : {}) }}>⚠ Probija rok: <b>{probijaUk}</b></span>
                <span style={{ color: "#64748b", fontSize: 12, fontWeight: 700 }}>pon–pet 2 smene · subota 1 smena · klizač na dnu za sledeće nedelje · datumi uživo</span>
                <div style={{ marginLeft: "auto", display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
                    <label style={{ ...chip, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 6 }}>
                        <input type="checkbox" checked={prikaziPrazne} onChange={(e) => setPrikaziPrazne(e.target.checked)} style={{ accentColor: "#1d4ed8" }} />
                        prikaži i prazne
                    </label>
                    <span style={{ display: "inline-flex", border: "1px solid #cbd5e1", borderRadius: 999, overflow: "hidden" }}>
                        <button onClick={() => setPrikaz("dan")} style={{ border: "none", cursor: "pointer", fontWeight: 900, fontSize: 12.5, padding: "6px 14px", background: jeDan ? "#0f172a" : "#fff", color: jeDan ? "#fff" : "#334155" }}>Dan</button>
                        <button onClick={() => setPrikaz("nedelja")} style={{ border: "none", cursor: "pointer", fontWeight: 900, fontSize: 12.5, padding: "6px 14px", background: !jeDan ? "#0f172a" : "#fff", color: !jeDan ? "#fff" : "#334155" }}>Nedelja</button>
                    </span>
                    {jeDan ? (
                        <>
                            <button onClick={() => setDanPomak(danPomak - 1)} style={{ ...chip, cursor: "pointer", fontWeight: 900 }}>‹ pret.</button>
                            <button onClick={() => setDanPomak(0)} style={{ ...chip, cursor: "pointer" }}>Danas</button>
                            <button onClick={() => setDanPomak(danPomak + 1)} style={{ ...chip, cursor: "pointer", fontWeight: 900 }}>sled. ›</button>
                        </>
                    ) : (
                        <>
                            <button onClick={() => setNedelja(nedelja - 1)} style={{ ...chip, cursor: "pointer", fontWeight: 900 }}>‹ pret.</button>
                            <button onClick={() => setNedelja(0)} style={{ ...chip, cursor: "pointer" }}>Danas</button>
                            <button onClick={() => setNedelja(nedelja + 1)} style={{ ...chip, cursor: "pointer", fontWeight: 900 }}>sled. ›</button>
                        </>
                    )}
                </div>
            </div>

            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 8 }}>
                {[['sve', 'Sve'], ['stampa', 'Štamparije'], ['rezanje', 'Rezači'], ['kese', 'Kese'], ['spulne', 'Špulne'], ['kasiranje', 'Kaширanje']].map(([k, l]) =>
                    <button key={k} onClick={() => setGrupa(k)} style={{ border: '1px solid #cbd5e1', background: grupa === k ? '#0f172a' : '#fff', color: grupa === k ? '#fff' : '#334155', borderRadius: 9, padding: '6px 12px', fontWeight: 800, fontSize: 12.5, cursor: 'pointer' }}>{l}</button>)}
            </div>
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap", fontSize: 11.5, fontWeight: 800, color: "#475569", marginBottom: 10 }}>
                {[["stampa", "Štampa"], ["rezanje", "Rezanje"], ["kasiranje", "Kaширanje"], ["kese", "Kese"], ["spulne", "Špulne"]].map(([k, l]) =>
                    <span key={k} style={{ display: "inline-flex", alignItems: "center", gap: 5 }}><span style={{ width: 14, height: 10, borderRadius: 3, background: OP_BOJA[k] }} />{l}</span>)}
                <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}><span style={{ width: 14, height: 10, borderRadius: 3, border: "1.5px dashed #f59e0b", background: "repeating-linear-gradient(45deg,#e2e8f0 0 4px,#f8fafc 4px 8px)" }} />Čeka prethodnu</span>
                <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}><span style={{ width: 14, height: 10, borderRadius: 3, background: "#7c3aed" }} />U štampariji</span>
                <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}><span style={{ width: 3, height: 14, borderRadius: 2, background: "#dc2626" }} />Rok</span>
            </div>

            <div ref={wrapRef} style={{ ...kartica, overflowX: "auto", overflowY: "hidden" }}>
                <div style={{ minWidth: dani.ukupno + 8 }}>
                    {/* zaglavlje dana */}
                    <div style={{ display: "flex", borderBottom: "2px solid #e2e8f0", position: "sticky", top: 0, background: "#fff", zIndex: 3 }}>
                        <div style={{ width: IME_PX, flex: "0 0 " + IME_PX + "px", padding: "9px 12px", fontSize: 10, fontWeight: 900, color: "#94a3b8", textTransform: "uppercase" }}>Mašina</div>
                        {dani.lista.map((c, i) => {
                            const jeDanas = new Date(c.datum).setHours(0, 0, 0, 0) === danas.getTime();
                            return <div key={i} style={{ width: c.w, flex: "0 0 " + c.w + "px", padding: "9px 10px", borderLeft: "1px solid #eef1f5", textAlign: "center", fontSize: 13, fontWeight: 900, color: jeDanas ? "#1d4ed8" : (c.subota ? "#b45309" : "#334155"), background: jeDanas ? "#eff6ff" : (c.subota ? "#fffbeb" : undefined) }}>
                                {c.datum.toLocaleDateString("sr-RS", { weekday: "long" }).toUpperCase()}
                                <div style={{ color: c.subota ? "#d97706" : "#94a3b8", fontWeight: 700, fontSize: 11, marginTop: 2 }}>{c.datum.getDate()}. {c.datum.toLocaleDateString("sr-RS", { month: "short" })}{jeDanas ? " · danas" : (c.subota ? " · 1 smena" : "")}</div>
                            </div>;
                        })}
                    </div>

                    {jeDan && (
                        <div style={{ display: "flex", borderBottom: "1px solid #eef1f5", background: "#fff" }}>
                            <div style={{ width: IME_PX, flex: "0 0 " + IME_PX + "px" }} />
                            <div style={{ position: "relative", flex: 1, height: 20 }}>
                                {satiRuler.map((h, i) => (
                                    <div key={i} style={{ position: "absolute", left: h.x - IME_PX, top: 0, bottom: 0, borderLeft: "1px solid #eef1f5" }}>
                                        <span style={{ position: "absolute", left: 3, top: 2, fontSize: 9.5, color: "#94a3b8", fontWeight: 800, whiteSpace: "nowrap" }}>{h.label}</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {vidljive.length === 0 && <div style={{ padding: 26, textAlign: "center", color: "#94a3b8", fontWeight: 800 }}>Nema mašina sa nalozima za izabrani filter — uključi "prikaži i prazne" ili prevuci naloge na tabu Mašine.</div>}
                    {vidljive.map((m) => {
                        const moji = raspored.filter((s) => s.masinaId === m.id).sort((a, b) => a.start - b.start);
                        // dnevni prikaz: prikaži trake koje se preklapaju sa danom — uključujući period ČEKANJA
                        // (mašina "čeka prethodnu" traje od cekaOdWm do starta, pa red nije prazan tog dana)
                        const mojiV = (jeDan && danBounds) ? moji.filter((s) => {
                            const vidljivOd = (s.cekaOdWm !== null && s.cekaOdWm !== undefined) ? wmToDate(sidro, s.cekaOdWm) : s.start;
                            return vidljivOd < danBounds.e && s.end > danBounds.s;
                        }) : moji;
                        return (
                            <React.Fragment key={m.id}>
                                <div onDragOver={(e) => e.preventDefault()} onDrop={(e) => dropToMachine && dropToMachine(m.id, e)}
                                    style={{ display: "flex", borderBottom: "1px solid #f1f5f9" }}>
                                    <div style={{ width: IME_PX, flex: "0 0 " + IME_PX + "px", padding: "10px 12px", borderRight: "1px solid #e2e8f0" }}>
                                        <div style={{ fontSize: 11, color: "#94a3b8", fontWeight: 900, letterSpacing: ".3px" }}>{m.code} · {(m.group || m.type || "").toString().toUpperCase()}</div>
                                        <b style={{ fontSize: 17, lineHeight: 1.2, display: "block", margin: "1px 0 2px" }}>{m.name}</b>
                                        <div style={{ fontSize: 12.5, color: "#475569", fontWeight: 800 }}>{m.speed || "—"} m/min · setup {m.setupMin || 0}{m.status !== "aktivna" ? " · 🔧 " + m.status : ""}</div>
                                    </div>
                                    <div style={{ position: "relative", flex: 1, height: RED_PX, minHeight: RED_PX }}>
                                        {dani.lista.map((c, i) => <div key={i} style={{ position: "absolute", left: c.x - IME_PX, width: c.w, top: 0, bottom: 0, borderLeft: "1px solid #f1f5f9", background: c.subota ? "#fffdf5" : undefined }} />)}
                                        {jeDan && satiRuler.map((h, i) => <div key={"h" + i} style={{ position: "absolute", left: h.x - IME_PX, top: 0, bottom: 0, borderLeft: "1px solid #f1f5f9" }} />)}
                                        {mojiV.map((s, i) => {
                                            const x1 = xOd(s.start) - IME_PX, x2 = xOd(s.end) - IME_PX;
                                            const boja = s.eksterno ? "#7c3aed" : (OP_BOJA[s.o.opTip] || "#64748b");
                                            const cx1 = s.cekaOdWm !== null ? xOd(wmToDate(sidro, s.cekaOdWm)) - IME_PX : null;
                                            return (
                                                <React.Fragment key={s.o.id + i}>
                                                    {cx1 !== null && x1 - cx1 > 8 && (
                                                        <div title={"Čeka " + (OP_LABELE[s.ceka] || s.ceka || "prethodnu")} style={{ position: "absolute", left: cx1, width: x1 - cx1 - 4, top: 9, bottom: 9, borderRadius: 11, border: "1.5px dashed #f59e0b", background: "repeating-linear-gradient(45deg,#e9edf3 0 6px,#f8fafc 6px 12px)", color: "#92400e", fontSize: 11, fontWeight: 900, padding: "0 12px", overflow: "hidden", boxSizing: "border-box", display: "flex", flexDirection: "column", justifyContent: "center", gap: 2 }}>
                                                            <div>⏳ čeka {OP_LABELE[s.ceka] || s.ceka || ""}</div>
                                                            <div style={{ fontWeight: 700, fontSize: 9.5, opacity: .8 }}>mašina slobodna dotad</div>
                                                        </div>)}
                                                    {(() => {
                                                        const w = Math.max(46, x2 - x1 - 4);
                                                        const sirokoDosta = w >= 130;   // dovoljno za pun sadržaj
                                                        const srednje = w >= 74;          // bar broj naloga
                                                        const metri = s.o.metri ? Number(s.o.metri).toLocaleString("sr-RS") + " m" : "";
                                                        const detalj = [s.o.title, s.o.customer].filter(Boolean).join(" · ");
                                                        return (
                                                            <div draggable={!!dragStart} onDragStart={(e) => dragStart && dragStart(e, s.o.id)}
                                                                title={s.o.id + " · " + (s.o.title || "") + (s.o.customer ? " · " + s.o.customer : "") + "\nstart: " + fmtT(s.start) + "\ngotov: " + fmtT(s.end) + (s.o.rok ? "\nrok: " + new Date(s.o.rok).toLocaleDateString("sr-RS") : "") + (s.pretpostavka ? "\n(pretpostavljen povratak iz štamparije)" : "")}
                                                                style={{ position: "absolute", left: x1, width: w, top: 12, bottom: 12, borderRadius: 12, background: boja, color: "#fff", padding: srednje ? "9px 13px" : "6px", overflow: "hidden", boxSizing: "border-box", cursor: "grab", boxShadow: "0 4px 12px rgba(15,23,42,.2)", opacity: s.o.status === "u_radu" ? 1 : .94, outline: s.probija ? "2px solid #fecaca" : "none", zIndex: 1, display: "flex", flexDirection: "column", gap: 4, justifyContent: "center", alignItems: srednje ? "stretch" : "center" }}>
                                                                <div style={{ fontSize: 14, fontWeight: 900, lineHeight: 1.15, display: "flex", alignItems: "center", gap: 5, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                                                                    {s.eksterno ? "📦 " : (s.o.opIkona ? s.o.opIkona + " " : "")}{srednje ? s.o.id : ""}
                                                                </div>
                                                                {sirokoDosta && detalj && <div style={{ fontSize: 12, fontWeight: 700, opacity: .98, lineHeight: 1.25, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{detalj}</div>}
                                                                {sirokoDosta && (metri || s.o.brojBoja) && <div style={{ fontSize: 11.5, fontWeight: 700, opacity: .92, whiteSpace: "nowrap" }}>{[metri, s.o.brojBoja ? s.o.brojBoja + " boja" : "", s.o.brojTraka > 1 ? s.o.brojTraka + " trake" : ""].filter(Boolean).join(" · ")}</div>}
                                                                {srednje && <div style={{ marginTop: 2, fontSize: 11.5, fontWeight: 900, background: "rgba(255,255,255,.24)", borderRadius: 7, padding: "3px 9px", width: "fit-content", whiteSpace: "nowrap" }}>{s.eksterno ? "povratak " + fmtD(s.end) : "gotov " + fmtT(s.end)}{s.probija ? " ⚠+" + s.kasniDana + "d" : ""}{s.uskok ? " ↷" : ""}</div>}
                                                            </div>);
                                                    })()}
                                                    {s.rokD && <div title={"Rok " + s.o.id} style={{ position: "absolute", left: xOd(s.rokD) - IME_PX, top: 4, bottom: 4, width: 2.5, background: "#dc2626", borderRadius: 2, zIndex: 3, pointerEvents: "none" }} />}
                                                </React.Fragment>
                                            );
                                        })}
                                        {mojiV.length === 0 && <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", color: "#e2e8f0", fontWeight: 800, fontSize: 11 }}>{jeDan ? "nema naloga za ovaj dan" : "prevuci nalog ovde"}</div>}
                                    </div>
                                </div>
                                {/* zauzetost po danu */}
                                <div style={{ display: "flex", borderBottom: "1px solid #e2e8f0" }}>
                                    <div style={{ width: IME_PX, flex: "0 0 " + IME_PX + "px", padding: "2px 12px", fontSize: 9, color: "#94a3b8", fontWeight: 800, textTransform: "uppercase", borderRight: "1px solid #e2e8f0" }}>zauzetost</div>
                                    {dani.lista.map((c, i) => {
                                        const dat = new Date(c.datum); dat.setHours(0, 0, 0, 0);
                                        const min = zauzetost[m.id + "|" + dat.getTime()] || 0;
                                        const cap = kapacitetDana(c.datum) || DAN_MIN;
                                        const pct = Math.round(min / cap * 100);
                                        const st = pct === 0 ? { color: "#cbd5e1" } : pct < 60 ? { background: "#f0fdf4", color: "#15803d" } : pct <= 90 ? { background: "#fffbeb", color: "#b45309" } : { background: "#fef2f2", color: "#dc2626" };
                                        return <div key={i} style={{ width: c.w, flex: "0 0 " + c.w + "px", height: 23, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 900, borderLeft: "1px solid #f1f5f9", ...st }}>{pct ? pct + "%" : "—"}</div>;
                                    })}
                                </div>
                            </React.Fragment>
                        );
                    })}
                </div>
            </div>

            <div style={{ color: "#64748b", fontSize: 11.5, marginTop: 10, fontWeight: 700 }}>
                💡 Prevuci traku na drugu mašinu — svi datumi se odmah preračunaju. Redosled unutar mašine menjaš strelicama ▲▼ na tabu "Mašine".
                Isprekidano = čekanje prethodne operacije (mašina tada radi druge naloge). "↷" = uskočio u rupu ispred naloga koji čeka.
            </div>
        </div>
    );
}
