import React, { useState, useEffect, useCallback, useRef } from "react";
import { getNavGroups } from "./config/navigation.js";
import { LanguageProvider, useLang, LanguageSwitcher } from "./LanguageProvider.jsx";
import { supabase } from "./supabase.js";
import { LOGO_B64, SPULNA_B64 } from "./constants.js";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import AIAsistentKalkulacije from "./AIAsistent-Kalkulacije.jsx";
import PregledNalogaPRO from "./PregledNalogaPRO.jsx";
import RadnikOperacija from "./RadnikOperacija.jsx";
import ProductTemplateEngineV20 from "./ProductTemplateEngineV20.jsx";
import UvozSpulnaExcel from "./UvozSpulnaExcel.jsx";
import ProductMasterPRO from "./ProductMasterPRO.jsx";
import ListaProizvodaKupci from './ListaProizvodaKupci.jsx';
import AnalizaMaterijalStavke from './AnalizaMaterijalStavke.jsx';
import PonudePRO from "./PonudePRO.jsx";
import KalkulacijaFolije from "./KalkulacijaFolije.jsx";
import KalkulacijaKese from "./KalkulacijaKese.jsx";
import KalkulacijaSpulne from "./KalkulacijaSpulne.jsx";
import KalkulatorMaticnihRolni from "./KalkulatorMaticnihRolni.jsx";
import PlanerRezanjaIzMagacina from "./PlanerRezanjaIzMagacina.jsx";
import QRCode from "qrcode";


// ============================================================================
// FRONTEND ERROR LOGGER - hvata beli ekran / mobilne QR greške
// Upisuje grešku u Supabase tabelu public.frontend_errors
// ============================================================================
function stringifyFrontendError(value) {
    try {
        if (!value) return "";
        if (typeof value === "string") return value;
        if (value?.message) return String(value.message);
        return JSON.stringify(value);
    } catch (_) {
        return String(value || "");
    }
}

async function logFrontendErrorToSupabase(message, stack = "") {
    try {
        if (!supabase || supabase.__notConfigured) return;
        await supabase.from("frontend_errors").insert({
            message: stringifyFrontendError(message),
            stack: stringifyFrontendError(stack),
            url: String(window.location.href || ""),
            user_agent: String(navigator.userAgent || "")
        });
    } catch (e) {
        // Ne sme da ruši aplikaciju ako logovanje greške ne uspe.
        console.error("Frontend error logging failed:", e);
    }
}

if (typeof window !== "undefined" && !window.__MAROPACK_FRONTEND_ERROR_LOGGER__) {
    window.__MAROPACK_FRONTEND_ERROR_LOGGER__ = true;

    window.addEventListener("error", (event) => {
        logFrontendErrorToSupabase(
            event?.message || "window.error",
            event?.error?.stack || `${event?.filename || ""}:${event?.lineno || ""}:${event?.colno || ""}`
        );
    });

    window.addEventListener("unhandledrejection", (event) => {
        logFrontendErrorToSupabase(
            event?.reason?.message || event?.reason || "unhandledrejection",
            event?.reason?.stack || ""
        );
    });
}

// ✅ AUTH SISTEM - NOVI IMPORT-I
import { AuthProvider, useAuth } from './auth/AuthProvider';
import Login from './auth/Login';
import ProtectedRoute from './auth/ProtectedRoute';
import AuditLog from './admin/AuditLog';
import UserManagement from './UserManagement';

// ✅ RADNIK & MAGACIN PANEL - NOVI SISTEM

// ✅ MANAGER DASHBOARD
import ManagerDashboard from './components/ManagerDashboard/ManagerDashboard';

// ✅ LISTA KALKULACIJA
import ListaKalkulacija from './ListaKalkulacija';
import { kreirajPonuduIzKalkulacije } from './utils/kalkulacijeHelpers';
import { buildOrderSourcePack, extractTemplate, extractKalkulacija } from './utils/nalogDataLink';

// ✅ PRO MODULI
import DashboardPRO from './DashboardPRO.jsx';
import MobileApp from './MobileApp.jsx';

// ✅ AI MODULI
import AIProductionPlanner from './AIProductionPlanner.jsx';
import AIChatAssistant from './AIChatAssistant.jsx';
import AIWasteOptimizer from './AIWasteOptimizer.jsx';
import AIQualityInspector from './AIQualityInspector.jsx';
import FormatiranjeRolniPRO from './modules/FormatiranjeRolniPRO.jsx';
import FormatiranjePoPotrebi from './modules/FormatiranjePoPotrebi.jsx';
import ProductionPlannerPRO from './modules/ProductionPlannerPRO.jsx';
import RolneWarehouseEngine from './modules/RolneWarehouseEngine.jsx';
import LiveProductionMES from './modules/LiveProductionMES.jsx';
import QualityControlPRO from './modules/QualityControlPRO.jsx';
import FinansijeKPI_PRO from './modules/FinansijeKPI_PRO.jsx';
import TehnickiListPRO from './modules/TehnickiListPRO.jsx';
import ProductAIWorkflow from './modules/ProductAIWorkflow.jsx';
import DocumentAIWorkflow from './modules/DocumentAIWorkflow.jsx';
import SystemStatusPRO from './modules/SystemStatusPRO.jsx';
import BackupSecurityCenter from './modules/BackupSecurityCenter.jsx';
import MachineSchedulerPRO from './modules/MachineSchedulerPRO.jsx';
import AIAgentCommandCenter from './modules/AIAgentCommandCenter.jsx';
import AIPomoc from './modules/AIPomoc.jsx';
import SystemStabilizationCenter from './modules/SystemStabilizationCenter.jsx';
import ProductionHardeningCenter from './modules/ProductionHardeningCenter.jsx';
import FinalQADeploymentCenter from './modules/FinalQADepoymentCenter.jsx';
import FinalProductionReadinessCenter from './modules/FinalProductionReadinessCenter.jsx';
import AppErrorBoundary from './components/AppErrorBoundary.jsx';
import { fetchCoreData, generateMasterFromPonuda } from './services/supabaseCore.js';

// Mapira "bogati" nalog objekat na STVARNE kolone tabele nalozi.
// Sve nepoznato (payload-ovi, source_chain, aliasi…) ide u jsonb link_meta,
// pa se pri čitanju vraća nazad (enrichNalogForPrint).
const NALOG_CONSUMED = new Set([
    "broj_naloga", "ponBr", "broj", "tip_proizvoda", "tip", "naziv_proizvoda", "proizvod", "prod", "naziv",
    "kupac", "kolicina", "kol", "status", "qr_kod", "qr_code", "kalkulacija_id", "ponuda_id", "ponId",
    "specifikacija", "struktura", "mats", "tip_naloga", "vrsta", "operacija", "materijali_struktura",
    "template_id", "product_master_id", "datum_kreiranja", "datum_isporuke", "link_meta", "id", "created_at"
]);
function toNalogRow(o = {}) {
    const x = o || {};
    const kalkId = (x.kalkulacija_id != null && x.kalkulacija_id !== "" && !Number.isNaN(Number(x.kalkulacija_id))) ? Number(x.kalkulacija_id) : null;
    const row = {
        broj_naloga: x.broj_naloga || x.ponBr || x.broj || null,
        tip_proizvoda: x.tip_proizvoda || x.tip || null,
        naziv_proizvoda: x.naziv_proizvoda || x.proizvod || x.prod || x.naziv || null,
        kupac: x.kupac || null,
        kolicina: Number(x.kolicina ?? x.kol) || null,
        status: x.status || "Ceka",
        qr_kod: x.qr_kod || x.qr_code || null,
        qr_code: x.qr_code || x.qr_kod || null,
        kalkulacija_id: kalkId,
        ponuda_id: x.ponuda_id ?? x.ponId ?? null,
        proizvod: x.proizvod || x.prod || x.naziv_proizvoda || null,
        specifikacija: x.specifikacija || x.struktura || x.mats || null,
        tip_naloga: x.tip_naloga || x.vrsta || null,
        vrsta: x.vrsta || x.tip_naloga || null,
        operacija: x.operacija || x.naziv || null,
        materijali_struktura: x.materijali_struktura || x.struktura || x.mats || null,
        template_id: x.template_id != null ? String(x.template_id) : null,
        product_master_id: x.product_master_id || null,
    };
    const meta = {};
    for (const k in x) { if (!NALOG_CONSUMED.has(k) && x[k] !== undefined) meta[k] = x[k]; }
    row.link_meta = Object.keys(meta).length ? meta : null;
    return row;
}

// ==================== PROFESIONALNI NALOZI ====================
// Glavni prikaz je PregledNalogaPRO + NalogLayoutPRO.
// Stari posebni print importi su uklonjeni iz App.jsx da se ne mešaju dva izgleda naloga.

// ===================== MATERIJALI =====================
const MAT_DATA = {
    "BOPP": [5, 10, 15, 18, 20, 25, 28, 30, 35, 40, 45, 50, 55, 60, 65, 70].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP SEDEF": [5, 10, 15, 20, 25, 30, 35, 38, 40, 45].map(d => ({ d, t: +(d * 0.65).toFixed(2) })),
    "BOPP BELI": [5, 10, 15, 20, 25, 30, 35, 40, 45, 50].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "LDPE": [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60].map(d => ({ d, t: +(d * 0.925).toFixed(2) })),
    "CPP": [5, 10, 15, 18, 20, 25, 28, 30, 35, 40, 45, 50, 55, 60].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "PET": [12, 15, 19, 20, 21, 36, 50, 150].map(d => ({ d, t: +(d * 1.4).toFixed(2) })),
    "OPA": [12, 15, 20, 25, 30, 35, 40].map(d => ({ d, t: +(d * 1.1).toFixed(2) })),
    "OPP": [5, 10, 15, 18, 20, 25, 28, 30, 35, 40, 45, 50].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "PLA": [5, 10, 15, 20, 25, 30, 35, 40, 45].map(d => ({ d, t: +(d * 1.24).toFixed(2) })),
    "HDPE": [5, 8, 12, 15, 17, 20, 25, 30, 35, 40, 45, 50].map(d => ({ d, t: +(d * 0.94).toFixed(2) })),
    "ALU": [7, 9, 12, 15, 20, 25, 30, 35, 40, 45, 50].map(d => ({ d, t: +(d * 2.71).toFixed(2) })),
    "CELULOZA": [10, 15, 20, 23, 28, 30, 35, 40, 45, 50].map(d => ({ d, t: +(d * 1.45).toFixed(2) })),
    "CELOFAN": [10, 15, 20, 23, 28, 30, 35, 40, 45, 50].map(d => ({ d, t: +(d * 1.45).toFixed(2) })),
    "PA": [10, 15, 20, 23, 28, 30, 35, 40, 45, 50].map(d => ({ d, t: +(d * 1.14).toFixed(2) })),
    "PA/PE koestruzija": [10, 15, 20, 23, 28, 30, 35, 40, 45, 50].map(d => ({ d, t: +(d * 1.0).toFixed(2) })),
    "CPP PLC": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "CPP PLCB": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "CPP PLCBZ": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "CPP PLCDF": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "CPP PLCM": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "CPP PLCML": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "CPP PLCMLS": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "CPP PLCBAF": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXC": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXCB": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXCM": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXCMT": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXPMT": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXCFM": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXCW": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXPF": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXS": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXA": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXAA": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXPA": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXPM": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXPFM": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXPFB": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXPLA": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXPLF": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXPU": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXCLS": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXCMLS": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXCHFM": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXPBR": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXCHM": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
    "BOPP FXCMB": [12, 15, 18, 20, 25, 30, 35, 40, 45, 48, 50, 60, 70, 80, 90, 100].map(d => ({ d, t: +(d * 0.91).toFixed(2) })),
};

const CENE = {
    "BOPP": 3.1, "BOPP SEDEF": 3.5, "BOPP BELI": 3.2, "LDPE": 1.8, "CPP": 2.2,
    "PET": 3.5, "OPA": 4.0, "OPP": 2.9, "PLA": 3.8, "HDPE": 1.9, "ALU": 7.5,
    "CELULOZA": 3.0, "CELOFAN": 3.0, "PA": 4.2, "PA/PE koestruzija": 1.8,
    "CPP PLC": 2.4, "CPP PLCB": 2.4, "CPP PLCBZ": 2.4, "CPP PLCDF": 2.4,
    "CPP PLCM": 2.4, "CPP PLCML": 2.4, "CPP PLCMLS": 2.4, "CPP PLCBAF": 2.4,
    "BOPP FXC": 3.1, "BOPP FXCB": 3.1, "BOPP FXCM": 3.1, "BOPP FXCMT": 3.1,
    "BOPP FXPMT": 3.1, "BOPP FXCFM": 3.1, "BOPP FXCW": 3.1, "BOPP FXPF": 3.1,
    "BOPP FXS": 3.1, "BOPP FXA": 3.1, "BOPP FXAA": 3.1, "BOPP FXPA": 3.1,
    "BOPP FXPM": 3.1, "BOPP FXPFM": 3.1, "BOPP FXPFB": 3.1, "BOPP FXPLA": 3.1,
    "BOPP FXPLF": 3.1, "BOPP FXPU": 3.1, "BOPP FXCLS": 3.1, "BOPP FXCMLS": 3.1,
    "BOPP FXCHFM": 3.1, "BOPP FXPBR": 3.1, "BOPP FXCHM": 3.1, "BOPP FXCMB": 3.1,
};

const USERS = [
    { id: 1, ime: "Admin", uloga: "admin", pass: "admin123" },
    { id: 2, ime: "Jovana", uloga: "radnik", pass: "jovana123" },
    { id: 3, ime: "Jelena", uloga: "radnik", pass: "jelena123" },
    { id: 4, ime: "Dunja", uloga: "radnik", pass: "dunja123" },
    { id: 5, ime: "Tihana", uloga: "radnik", pass: "tihana123" },
    { id: 6, ime: "Milan", uloga: "radnik", pass: "milan123" },
];

const PREVODI = {
    sr: { ponuda: "PONUDA", br: "Broj", dat: "Datum", vaz: "Važi do", kup: "Kupac", adr: "Adresa", kon: "Kontakt", naz: "Naziv proizvoda", kol: "Količina (m)", jc: "Cena €/1000m", uk: "Ukupno €", nap: "Napomena", pot: "Ovlašćeno lice", pdv: "PDV nije uključen", hv: "Hvala na poverenju!", pl: "Plaćanje: 30 dana od fakture." },
    en: { ponuda: "QUOTATION", br: "Number", dat: "Date", vaz: "Valid until", kup: "Customer", adr: "Address", kon: "Contact", naz: "Product name", kol: "Quantity (m)", jc: "Unit price €/1000m", uk: "Total €", nap: "Note", pot: "Authorized person", pdv: "VAT not included", hv: "Thank you for your business!", pl: "Payment: 30 days from invoice." },
    de: { ponuda: "ANGEBOT", br: "Nummer", dat: "Datum", vaz: "Gültig bis", kup: "Kunde", adr: "Adresse", kon: "Kontakt", naz: "Produktname", kol: "Menge (m)", jc: "Einzelpreis €/1000m", uk: "Gesamt €", nap: "Bemerkung", pot: "Bevollmächtigte Person", pdv: "MwSt. nicht enthalten", hv: "Vielen Dank!", pl: "Zahlung: 30 Tage nach Rechnung." },
};

const BOJE = ["#1d4ed8", "#7c3aed", "#0891b2", "#059669"];
const SLOJ = ["A", "B", "C", "D"];
const EM = { tip: "", deb: "", cena: "", stamp: false, kas: 0, lak: 0 };
const f2 = v => isNaN(v) || v === null ? "—" : (+v).toFixed(2).replace(".", ",");
const f4 = v => isNaN(v) || v === null ? "—" : (+v).toFixed(4).replace(".", ",");
const eu = v => f2(v) + " €";
const dnow = () => new Date().toLocaleDateString("sr-RS");
const nbr = () => "MP-" + new Date().getFullYear() + "-" + String(Math.floor(Math.random() * 9000) + 1000);

// ===================== KOMPONENTE =====================
function Counter({ val, set, max, lab, col }) {
    return (
        <div>
            <div style={{ fontSize: 10, fontWeight: 700, color: "#64748b", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 4 }}>{lab}</div>
            <div style={{ display: "flex", border: "1px solid #e2e8f0", borderRadius: 8, overflow: "hidden", background: "#f8fafc" }}>
                <button onClick={function () { set(Math.max(0, val - 1)); }} style={{ width: 32, height: 36, border: "none", background: "transparent", cursor: "pointer", fontSize: 16, color: "#94a3b8", fontWeight: 700 }}>-</button>
                <div style={{ flex: 1, textAlign: "center", fontSize: 14, fontWeight: 700, padding: "6px 0", color: val > 0 ? col : "#cbd5e1", background: val > 0 ? col + "15" : "transparent", borderLeft: "1px solid #e2e8f0", borderRight: "1px solid #e2e8f0" }}>{val}x</div>
                <button onClick={function () { set(Math.min(max, val + 1)); }} style={{ width: 32, height: 36, border: "none", background: "transparent", cursor: "pointer", fontSize: 16, color: "#94a3b8", fontWeight: 700 }}>+</button>
            </div>
        </div>
    );
}

function Notif({ msg, tip }) {
    return (
        <div style={{ position: "fixed", top: 20, right: 20, zIndex: 9999, background: tip === "err" ? "#fef2f2" : "#f0fdf4", border: "1px solid " + (tip === "err" ? "#fecaca" : "#bbf7d0"), color: tip === "err" ? "#ef4444" : "#16a34a", borderRadius: 10, padding: "12px 20px", fontWeight: 600, fontSize: 13, boxShadow: "0 4px 20px rgba(0,0,0,0.1)" }}>
            {msg}
        </div>
    );
}

function RezultatiKalk({ res, nal, met }) {
    if (!res) return null;
    var card = { background: "#fff", borderRadius: 12, padding: 16, border: "1px solid #e8edf3" };
    var lbl = { fontSize: 9, fontWeight: 700, color: "#64748b", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 2, display: "block" };
    return (
        <div style={{ display: "grid", gap: 12 }}>
            {/* Cene */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8 }}>
                {[
                    ["Osn. cena / 1000m", res.osn_1000, "#64748b"],
                    ["Osn. cena / kg", res.osn_kg, "#64748b"],
                    ["Osn. cena nalog", res.osn_nalog, "#64748b"],
                ].map(function (x) {
                    return (
                        <div key={x[0]} style={Object.assign({}, card, { background: "#f8fafc" })}>
                            <span style={lbl}>{x[0]}</span>
                            <div style={{ fontSize: 15, fontWeight: 800, color: x[2] }}>{eu(x[1])}</div>
                        </div>
                    );
                })}
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8 }}>
                {[
                    ["Cena sa maržom / 1000m", res.k1, "#1d4ed8"],
                    ["Cena sa maržom / kg", res.kkg, "#1d4ed8"],
                    ["Cena sa maržom nalog", res.kn, "#059669"],
                ].map(function (x) {
                    return (
                        <div key={x[0]} style={Object.assign({}, card, { background: x[2] + "08", border: "1.5px solid " + x[2] + "30" })}>
                            <span style={lbl}>{x[0]}</span>
                            <div style={{ fontSize: 15, fontWeight: 800, color: x[2] }}>{eu(x[1])}</div>
                        </div>
                    );
                })}
            </div>
            {/* Potrebe materijala */}
            <div style={card}>
                <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 10 }}>📦 Potrebe materijala za nalog ({nal}x1000m)</div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(200px,1fr))", gap: 8 }}>
                    {res.det.map(function (m, i) {
                        return (
                            <div key={i} style={{ background: BOJE[i] + "08", border: "1px solid " + BOJE[i] + "30", borderRadius: 8, padding: "10px 12px" }}>
                                <div style={{ fontWeight: 700, fontSize: 12, color: BOJE[i], marginBottom: 4 }}>{SLOJ[i]}: {m.tip} {m.deb}µ</div>
                                <div style={{ fontSize: 12, color: "#475569" }}>Težina: <b>{f2(m.tg)} g/m²</b></div>
                                <div style={{ fontSize: 12, color: "#475569" }}>Ukupno kg: <b>{f2(m.tkg_nalog)} kg</b></div>
                                <div style={{ fontSize: 12, color: "#475569" }}>Ukupno m: <b>{f2(+met * +nal * 1000)} m</b></div>
                            </div>
                        );
                    })}
                    {res.ukLep > 0 && (
                        <div style={{ background: "#fef9c3", border: "1px solid #fde047", borderRadius: 8, padding: "10px 12px" }}>
                            <div style={{ fontWeight: 700, fontSize: 12, color: "#854d0e", marginBottom: 4 }}>🔗 Lepak</div>
                            <div style={{ fontSize: 12, color: "#475569" }}>Ukupno kg: <b>{f2(res.ukLep_nalog)} kg</b></div>
                        </div>
                    )}
                    {res.ukLakM > 0 && (
                        <div style={{ background: "#f5f3ff", border: "1px solid #c4b5fd", borderRadius: 8, padding: "10px 12px" }}>
                            <div style={{ fontWeight: 700, fontSize: 12, color: "#7c3aed", marginBottom: 4 }}>✨ Lak</div>
                            <div style={{ fontSize: 12, color: "#475569" }}>Ukupno kg: <b>{f2(res.ukLakM_nalog)} kg</b></div>
                        </div>
                    )}
                </div>
            </div>
            {/* Struktura troškova */}
            <div style={card}>
                <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 10 }}>📊 Struktura troškova</div>
                {[["Materijali", res.ukM], ["Lepak", res.ukLep], ["Lak mat.", res.ukLakM], ["Kasiranje", res.ukKas], ["Stampa", res.ukSt], ["Lakiranje usl.", res.ukLakU], ["Transport", res.ukTr], ["Pakovanje", res.ukPk]].map(function (x) {
                    var pct = res.osn > 0 ? x[1] / res.osn * 100 : 0;
                    return (
                        <div key={x[0]} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
                            <div style={{ width: 130, fontSize: 11, color: "#64748b" }}>{x[0]}</div>
                            <div style={{ flex: 1, height: 6, background: "#f1f5f9", borderRadius: 3, overflow: "hidden" }}>
                                <div style={{ height: "100%", background: "#1d4ed8", borderRadius: 3, width: Math.max(pct, 0.3) + "%" }} />
                            </div>
                            <div style={{ width: 75, textAlign: "right", fontSize: 11, fontWeight: 600 }}>{f4(x[1])} €</div>
                            <div style={{ width: 30, textAlign: "right", fontSize: 10, color: "#94a3b8" }}>{pct.toFixed(0)}%</div>
                        </div>
                    );
                })}
                <div style={{ borderTop: "2px solid #e2e8f0", paddingTop: 8, marginTop: 8, display: "flex", justifyContent: "space-between", fontWeight: 700, fontSize: 13 }}>
                    <span>OSNOVNA CENA / 1000m</span><span style={{ color: "#1d4ed8" }}>{f4(res.osn_1000)} €</span>
                </div>
            </div>
        </div>
    );
}

function PonudaView({ t, naziv, kupac, adr, kon, kol, c1, uk, nap, mats, broj, dat, vaz, printRef, tip }) {
    var f2l = function (v) { return isNaN(v) ? "—" : (+v).toFixed(2).replace(".", ","); };
    var kolLabel = tip === "kesa" ? "Količina (kom)" : tip === "spulna" ? "Količina (špulni)" : "Količina (m)";
    return (
        <div ref={printRef} style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 10, padding: 28, fontFamily: "'Segoe UI',serif" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20, paddingBottom: 16, borderBottom: "2px solid #1d4ed8" }}>
                <div>
                    <img src={LOGO_B64} alt="Maropack" style={{ height: 50, objectFit: "contain" }} />
                    <div style={{ fontSize: 11, color: "#64748b", marginTop: 4 }}>Fleksibilna ambalaza · Srbija</div>
                </div>
                <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 20, fontWeight: 800, color: "#1d4ed8" }}>{t.ponuda}</div>
                    {broj && <div style={{ fontSize: 11, color: "#64748b", marginTop: 3 }}>{t.br}: <b>{broj}</b></div>}
                    {dat && <div style={{ fontSize: 11, color: "#64748b" }}>{t.dat}: <b>{dat}</b></div>}
                    {vaz && <div style={{ fontSize: 11, color: "#64748b" }}>{t.vaz}: <b>{vaz}</b></div>}
                </div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 20 }}>
                <div style={{ background: "#f8fafc", borderRadius: 8, padding: "12px 14px" }}>
                    <div style={{ fontSize: 9, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 6 }}>{t.kup}</div>
                    <div style={{ fontWeight: 700, fontSize: 13 }}>{kupac || "—"}</div>
                    {adr && <div style={{ fontSize: 11, color: "#64748b", marginTop: 2 }}>{adr}</div>}
                    {kon && <div style={{ fontSize: 11, color: "#64748b" }}>{kon}</div>}
                </div>
                <div style={{ background: "#eff6ff", borderRadius: 8, padding: "12px 14px" }}>
                    <div style={{ fontSize: 9, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 6 }}>{t.naz}</div>
                    <div style={{ fontWeight: 700, fontSize: 13 }}>{naziv || "—"}</div>
                    {mats && mats.filter(function (m) { return m.tip; }).length > 0 && (
                        <div style={{ fontSize: 10, color: "#64748b", marginTop: 3 }}>{mats.filter(function (m) { return m.tip; }).map(function (m) { return m.tip + " " + (m.deb || m.debljina) + "µ"; }).join(" / ")}</div>
                    )}
                </div>
            </div>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12, marginBottom: 16 }}>
                <thead>
                    <tr style={{ background: "#1d4ed8", color: "#fff" }}>
                        <th style={{ padding: "9px 10px", textAlign: "left" }}>{t.naz}</th>
                        <th style={{ padding: "9px 10px", textAlign: "right" }}>{kolLabel}</th>
                        <th style={{ padding: "9px 10px", textAlign: "right" }}>{t.jc}</th>
                        <th style={{ padding: "9px 10px", textAlign: "right" }}>{t.uk}</th>
                    </tr>
                </thead>
                <tbody>
                    <tr style={{ borderBottom: "1px solid #e2e8f0" }}>
                        <td style={{ padding: "10px" }}>{naziv || "—"}</td>
                        <td style={{ padding: "10px", textAlign: "right" }}>{(kol || 0).toLocaleString()}</td>
                        <td style={{ padding: "10px", textAlign: "right" }}>{f2l(c1)}</td>
                        <td style={{ padding: "10px", textAlign: "right", fontWeight: 700 }}>{f2l(uk)}</td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr style={{ background: "#f8fafc" }}>
                        <td colSpan={3} style={{ padding: "10px", fontWeight: 700, textAlign: "right" }}>{t.uk}:</td>
                        <td style={{ padding: "10px", fontWeight: 900, fontSize: 15, textAlign: "right", color: "#1d4ed8" }}>{f2l(uk)} €</td>
                    </tr>
                </tfoot>
            </table>
            <div style={{ fontSize: 10, color: "#94a3b8", marginBottom: 6 }}>* {t.pdv}</div>
            {nap && <div style={{ background: "#fffbeb", borderRadius: 7, padding: "9px 12px", fontSize: 11, color: "#92400e", marginBottom: 10 }}>📌 {t.nap}: {nap}</div>}
            <div style={{ borderTop: "1px solid #e2e8f0", paddingTop: 14, display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
                <div style={{ fontSize: 10, color: "#64748b" }}>{t.pl}</div>
                <div style={{ textAlign: "center" }}>
                    <div style={{ width: 100, borderTop: "1px solid #0f172a", paddingTop: 4, fontSize: 10, color: "#64748b" }}>{t.pot}</div>
                </div>
            </div>
            <div style={{ textAlign: "center", marginTop: 12, fontSize: 11, color: "#94a3b8", fontStyle: "italic" }}>{t.hv}</div>
        </div>
    );
}

function PrintA4({ data, onClose }) {
    const nalog = data.nalog;
    const isImage = /\.(jpg|jpeg|png|gif|webp)$/i.test(data.link);
    const isPdf = /\.pdf$/i.test(data.link);
    function print() { window.print(); }
    return (
        <>
            <style>{`@media print{body *{visibility:hidden;}.print-area,.print-area *{visibility:visible;}.print-area{position:absolute;left:0;top:0;width:210mm;min-height:297mm;}.no-print{display:none !important;}}`}</style>
            <div style={{ position: "fixed", top: 0, left: 0, right: 0, bottom: 0, background: "rgba(0,0,0,0.6)", zIndex: 10000, display: "flex", alignItems: "center", justifyContent: "center", padding: 20, overflow: "auto" }}>
                <div style={{ background: "#fff", borderRadius: 12, maxWidth: 900, width: "100%", maxHeight: "95vh", overflow: "auto", display: "flex", flexDirection: "column" }}>
                    <div className="no-print" style={{ padding: "14px 20px", borderBottom: "1px solid #e2e8f0", display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, background: "#fff", zIndex: 1 }}>
                        <div style={{ fontWeight: 700, fontSize: 14 }}>A4 prikaz - {data.naz}</div>
                        <div style={{ display: "flex", gap: 8 }}>
                            <button onClick={print} style={{ padding: "8px 18px", borderRadius: 8, border: "none", background: data.col, color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer" }}>🖨️ Štampaj</button>
                            <button onClick={onClose} style={{ padding: "8px 14px", borderRadius: 8, border: "1px solid #e2e8f0", background: "#fff", color: "#64748b", fontWeight: 700, fontSize: 13, cursor: "pointer" }}>✕</button>
                        </div>
                    </div>
                    <div className="print-area" style={{ padding: "20mm 15mm", fontFamily: "'Segoe UI',system-ui,sans-serif", color: "#0f172a", width: "100%", boxSizing: "border-box", background: "#fff" }}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", paddingBottom: 16, borderBottom: "3px solid " + data.col, marginBottom: 20 }}>
                            <img src={LOGO_B64} alt="Maropack" style={{ height: 45, objectFit: "contain" }} />
                            <div style={{ textAlign: "right" }}>
                                <div style={{ fontSize: 18, fontWeight: 800, color: data.col }}>{data.ik} {data.naz.toUpperCase()}</div>
                                <div style={{ fontSize: 11, color: "#64748b", marginTop: 4 }}>{new Date().toLocaleDateString("sr-RS")}</div>
                            </div>
                        </div>
                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12, marginBottom: 20 }}>
                            {[["Broj naloga", nalog.ponBr || "—"], ["Kupac", nalog.kupac || "—"], ["Proizvod", nalog.prod || nalog.naziv || "—"]].map(function (x) {
                                return <div key={x[0]} style={{ background: "#f8fafc", borderRadius: 8, padding: "10px 14px", border: "1px solid #e2e8f0" }}><div style={{ fontSize: 9, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 4 }}>{x[0]}</div><div style={{ fontSize: 14, fontWeight: 700 }}>{x[1]}</div></div>;
                            })}
                        </div>
                        <div style={{ border: "1px solid #e2e8f0", borderRadius: 10, overflow: "hidden", background: "#fafafa" }}>
                            {isImage && <div style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: 400 }}><img src={data.link} alt={data.naz} style={{ maxWidth: "100%", maxHeight: "180mm", display: "block" }} /></div>}
                            {isPdf && <iframe src={data.link} style={{ width: "100%", height: "180mm", border: "none" }} title={data.naz} />}
                            {!isImage && !isPdf && <div style={{ padding: 40, textAlign: "center", color: "#64748b" }}><div style={{ fontSize: 40, marginBottom: 10 }}>📄</div><a href={data.link} target="_blank" rel="noopener" style={{ color: data.col }}>Otvori dokument</a></div>}
                        </div>
                        <div style={{ marginTop: 20, display: "flex", justifyContent: "space-between", fontSize: 10, color: "#64748b" }}>
                            <div>Radnik: _____________________</div>
                            <div>Potpis: _____________________</div>
                            <div>Datum: {new Date().toLocaleDateString("sr-RS")}</div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

// ===================== NALOG IZ BAZE (bez ponude) =====================

// ===================== KALKULATOR FOLIJE (uklonjen) =====================
// Inline KalkulatorFolije je uklonjen — koristi se KalkulacijaFolije.jsx (stranica "kalk_folija").
// (Bio je mrtav kod: definisan ali nigde renderovan.)

// ===================== KALKULATOR SPULNE =====================
function KalkulatorSpulne({ user, msg, setPage, inp, card, lbl }) {
    const [naziv, setNaziv] = useState("");
    const [kupac, setKupac] = useState("");
    const [materijal, setMaterijal] = useState("");
    const [sirinaM, setSirinaM] = useState(360);
    const [W, setW] = useState(25);
    const [da, setDa] = useState(158);
    const [di, setDi] = useState(152);
    const [C, setC] = useState(0);
    const [G, setG] = useState(0);
    const [T, setT] = useState(180);
    const [D, setD] = useState(380);
    const [sideA, setSideA] = useState("Papir");
    const [sideB, setSideB] = useState("Silikon");
    const [maxMetara, setMaxMetara] = useState(8000);
    const [gramatura, setGramatura] = useState(60);
    const [cenaKg, setCenaKg] = useState(2.7);
    const [nalog, setNalog] = useState(100);
    const [sk, setSk] = useState(10);
    const [mar, setMar] = useState(40);
    const [pTr, setPTr] = useState(0.3);
    const [pPak, setPPak] = useState(0.2);
    const [nap, setNap] = useState("");
    const [ktab, setKtab] = useState("unos");
    const [res, setRes] = useState(null);
    const [aktivna, setAktivna] = useState(null);
    const [pkupac, setPkupac] = useState("");
    const [padr, setPadr] = useState("");
    const [pkon, setPkon] = useState("");
    const [pnap, setPnap] = useState("");
    const [pjez, setPjez] = useState("sr");

    useEffect(function () {
        if (!W || !maxMetara || !gramatura || !cenaKg || !sirinaM) { setRes(null); return; }
        var w = +W / 1000;
        var mPerSpulna = +maxMetara;
        var m2PerSpulna = w * mPerSpulna;
        var kgPerM2 = +gramatura / 1000;
        var kgPerSpulna = kgPerM2 * (+sirinaM / 1000) * mPerSpulna;
        var ukM2 = (+sirinaM / 1000) * (+nalog) * 1000;
        var brSpulni = Math.ceil(ukM2 / m2PerSpulna);
        var ukKg = kgPerM2 * ukM2;
        var ukMat = ukKg * (+cenaKg);
        var ukTr = (+pTr) * ukKg;
        var ukPk = +pPak;
        var osn = ukMat + ukTr + ukPk;
        var osn_m2 = ukM2 > 0 ? osn / ukM2 : 0;
        var osn_1000m2 = osn_m2 * 1000;
        var osn_kg = ukKg > 0 ? osn / ukKg : 0;
        var sas = osn * (1 + (+sk / 100));
        var mf = 1 + (+mar / 100);
        var kn = sas * mf;
        var k_1000m2 = (sas / ukM2) * 1000 * mf;
        var kkg = ukKg > 0 ? (kn / ukKg) : 0;
        setRes({ w, mPerSpulna, m2PerSpulna, kgPerSpulna, brSpulni, ukKg, ukM2, ukMat, ukTr, ukPk, osn, osn_m2, osn_1000m2, osn_kg, sas, kn, k_1000m2, kkg });
    }, [W, maxMetara, gramatura, cenaKg, sirinaM, nalog, sk, mar, pTr, pPak]);

    const f2l = function (v) { return (!v || isNaN(v)) ? "—" : (+v).toFixed(2).replace(".", ","); };
    const eu = function (v) { return f2l(v) + " €"; };

    async function sacuvaj() {
        if (!naziv.trim()) { msg("Unesite naziv!", "err"); return; }
        var p = { naziv, kupac, materijal, sirina_mat: +sirinaM, W: +W, da: +da, di: +di, C: +C, G: +G, T: +T, D: +D, side_a: sideA, side_b: sideB, max_metara: +maxMetara, napomena: nap, datum: new Date().toLocaleDateString("sr-RS"), ko: user.ime };
        try { const { error } = await supabase.from('spulne').insert([p]); if (error) throw error; msg("Špulna sacuvana!"); }
        catch (e) { msg("Greška: " + e.message, "err"); }
    }

    async function kreirajPonudu() {
        if (!naziv.trim() || !pkupac.trim()) { msg("Unesite naziv i kupca!", "err"); return; }
        if (!res) { msg("Najpre završiti kalkulaciju!", "err"); return; }
        var p = { broj: "MP-" + new Date().getFullYear() + "-" + String(Math.floor(Math.random() * 9000) + 1000), datum: new Date().toLocaleDateString("sr-RS"), vaz: new Date(Date.now() + 30 * 24 * 3600000).toLocaleDateString("sr-RS"), kupac: pkupac, adr: padr, kon: pkon, naziv, kol: res.brSpulni, c1: res.k_1000m2, uk: res.kn, mats: [], nap: pnap, jez: pjez, status: "Aktivna", ko: user.ime, res: Object.assign({}, res), tip: "spulna" };
        try { const { data, error } = await supabase.from('ponude').insert([p]).select(); if (error) throw error; setAktivna(data[0]); msg("Ponuda kreirana!"); }
        catch (e) { msg("Greška: " + e.message, "err"); }
    }

    return (
        <div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }}>
                <h2 style={{ margin: 0, fontSize: 20, fontWeight: 800 }}>🔄 Kalkulator špulne</h2>
                <div style={{ display: "flex", gap: 6 }}>
                    {[["unos", "📋 Unos"], ["param", "⚙️ Parametri"], ["pon", "📄 Ponuda"], ["rez", "📊 Rezultati"]].map(function (t) {
                        return <button key={t[0]} onClick={function () { setKtab(t[0]); }} style={{ padding: "7px 14px", borderRadius: 7, border: ktab === t[0] ? "none" : "1px solid #e2e8f0", cursor: "pointer", fontSize: 12, fontWeight: 700, background: ktab === t[0] ? "#7c3aed" : "#fff", color: ktab === t[0] ? "#fff" : "#64748b" }}>{t[1]}</button>;
                    })}
                </div>
            </div>

            {ktab === "unos" && (
                <div>
                    <div style={Object.assign({}, card, { marginBottom: 14 })}>
                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                            <div><label style={lbl}>Naziv *</label><input style={inp} value={naziv} onChange={function (e) { setNaziv(e.target.value); }} placeholder="npr. Trake 25mm - 8000m" /></div>
                            <div><label style={lbl}>Kupac</label><input style={inp} value={kupac} onChange={function (e) { setKupac(e.target.value); }} /></div>
                            <div><label style={lbl}>Materijal</label><input style={inp} value={materijal} onChange={function (e) { setMaterijal(e.target.value); }} placeholder="npr. Papir silikonizani 60gr" /></div>
                            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                                <div><label style={lbl}>Side A</label><input style={inp} value={sideA} onChange={function (e) { setSideA(e.target.value); }} /></div>
                                <div><label style={lbl}>Side B</label><input style={inp} value={sideB} onChange={function (e) { setSideB(e.target.value); }} /></div>
                            </div>
                        </div>
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
                        <div style={card}>
                            <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 12, color: "#7c3aed" }}>📐 Dimenzije špulne</div>
                            <img src={SPULNA_B64} alt="Skica" style={{ width: "100%", borderRadius: 8, border: "1px solid #e2e8f0", marginBottom: 12 }} />
                            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                                {[["W - širina trake mm", W, setW], ["da - spoljašnji prečnik hilzne mm", da, setDa], ["di - unutrašnji prečnik mm", di, setDi], ["C mm", C, setC], ["G - gap mm", G, setG], ["T - širina hilzne mm", T, setT], ["D - max prečnik mm", D, setD], ["Širina materijala mm", sirinaM, setSirinaM], ["Max metara na špulni", maxMetara, setMaxMetara]].map(function (x) {
                                    return <div key={x[0]}><label style={lbl}>{x[0]}</label><input type="number" style={inp} value={x[1]} onChange={function (e) { x[2](e.target.value); }} /></div>;
                                })}
                            </div>
                        </div>
                        <div>
                            <div style={Object.assign({}, card, { marginBottom: 14 })}>
                                <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 12 }}>📦 Materijal i nalog</div>
                                <div style={{ display: "grid", gap: 10 }}>
                                    {[["Gramatura materijala g/m²", gramatura, setGramatura], ["Cena materijala EUR/kg", cenaKg, setCenaKg], ["Nalog x1000m", nalog, setNalog], ["Škart %", sk, setSk], ["Marža %", mar, setMar]].map(function (x) {
                                        return <div key={x[0]}><label style={lbl}>{x[0]}</label><input type="number" style={inp} value={x[1]} onChange={function (e) { x[2](e.target.value); }} /></div>;
                                    })}
                                </div>
                            </div>
                            {res && (
                                <div style={Object.assign({}, card, { background: "linear-gradient(135deg,#f5f3ff,#ede9fe)", border: "1px solid #c4b5fd" })}>
                                    <div style={{ fontSize: 10, color: "#64748b", marginBottom: 2, fontWeight: 700 }}>CENA SA MARŽOM / 1000m²</div>
                                    <div style={{ fontSize: 26, fontWeight: 900, color: "#7c3aed" }}>{eu(res.k_1000m2)}</div>
                                    <div style={{ fontSize: 11, color: "#64748b", marginTop: 2 }}>Osnovna: {eu(res.osn_1000m2)} | Nalog: {eu(res.kn)}</div>
                                    <div style={{ marginTop: 12, display: "flex", gap: 8, flexWrap: "wrap" }}>
                                        <button style={{ padding: "8px 14px", borderRadius: 7, border: "none", background: "#059669", color: "#fff", fontWeight: 700, fontSize: 12, cursor: "pointer" }} onClick={sacuvaj}>💾 Sacuvaj</button>
                                        <button style={{ padding: "8px 14px", borderRadius: 7, border: "none", background: "#7c3aed", color: "#fff", fontWeight: 700, fontSize: 12, cursor: "pointer" }} onClick={function () { setKtab("pon"); if (kupac) setPkupac(kupac); }}>📄 Ponuda</button>
                                        <button style={{ padding: "8px 14px", borderRadius: 7, border: "none", background: "#1d4ed8", color: "#fff", fontWeight: 700, fontSize: 12, cursor: "pointer" }} onClick={function () { setKtab("rez"); }}>📊 Rezultati</button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {ktab === "param" && (
                <div style={card}>
                    <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 12 }}>⚙️ Parametri troškova</div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                        {[["Transport EUR/kg", pTr, setPTr, 0.01], ["Pakovanje EUR fiksno", pPak, setPPak, 0.01]].map(function (x) {
                            return <div key={x[0]}><label style={lbl}>{x[0]}</label><input type="number" style={inp} value={x[1]} step={x[3]} onChange={function (e) { x[2](e.target.value); }} /></div>;
                        })}
                    </div>
                </div>
            )}

            {ktab === "pon" && (
                <div>
                    <div style={Object.assign({}, card, { marginBottom: 14 })}>
                        <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 12 }}>📄 Podaci za ponudu</div>
                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
                            <div><label style={lbl}>Kupac *</label><input style={inp} value={pkupac} onChange={function (e) { setPkupac(e.target.value); }} /></div>
                            <div><label style={lbl}>Adresa</label><input style={inp} value={padr} onChange={function (e) { setPadr(e.target.value); }} /></div>
                            <div><label style={lbl}>Kontakt</label><input style={inp} value={pkon} onChange={function (e) { setPkon(e.target.value); }} /></div>
                            <div><label style={lbl}>Jezik</label>
                                <select style={inp} value={pjez} onChange={function (e) { setPjez(e.target.value); }}>
                                    <option value="sr">🇷🇸 Srpski</option><option value="en">🇬🇧 English</option><option value="de">🇩🇪 Deutsch</option>
                                </select>
                            </div>
                        </div>
                        <div><label style={lbl}>Napomena</label><textarea style={Object.assign({}, inp, { height: 60, resize: "vertical" })} value={pnap} onChange={function (e) { setPnap(e.target.value); }} /></div>
                    </div>
                    <div style={{ display: "flex", gap: 10 }}>
                        <button style={{ padding: "10px 20px", borderRadius: 8, border: "none", background: "#7c3aed", color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer" }} onClick={kreirajPonudu}>📄 Kreiraj ponudu</button>
                        {aktivna && <div style={{ padding: "10px 14px", borderRadius: 8, background: "#f0fdf4", border: "1px solid #bbf7d0", color: "#166534", fontSize: 12, fontWeight: 700 }}>✅ Ponuda {aktivna.broj} kreirana</div>}
                    </div>
                </div>
            )}

            {ktab === "rez" && (
                !res ? <div style={Object.assign({}, card, { textAlign: "center", padding: 40, color: "#94a3b8" })}>Unesite podatke u Unos tab.</div> : (
                    <div style={{ display: "grid", gap: 12 }}>
                        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8 }}>
                            {[["Osn. cena / 1000m²", res.osn_1000m2, "#64748b"], ["Osn. cena / kg", res.osn_kg, "#64748b"], ["Osnovna cena naloga", res.osn, "#64748b"], ["Cena sa maržom / 1000m²", res.k_1000m2, "#7c3aed"], ["Cena sa maržom / kg", res.kkg, "#7c3aed"], ["Cena sa maržom nalog", res.kn, "#059669"]].map(function (x) {
                                return (
                                    <div key={x[0]} style={Object.assign({}, card, { background: x[2] === "#059669" ? "#f0fdf4" : x[2] === "#7c3aed" ? "#f5f3ff" : "#f8fafc", border: "1.5px solid " + x[2] + "30" })}>
                                        <div style={{ fontSize: 9, color: "#64748b", fontWeight: 700, textTransform: "uppercase", marginBottom: 3 }}>{x[0]}</div>
                                        <div style={{ fontSize: 18, fontWeight: 900, color: x[2] }}>{eu(x[1])}</div>
                                    </div>
                                );
                            })}
                        </div>
                        <div style={card}>
                            <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 10 }}>📦 Potrebe za nalog ({nalog}×1000m)</div>
                            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(160px,1fr))", gap: 8 }}>
                                {[["Broj špulni", res.brSpulni + " kom", "#7c3aed"], ["Ukupno m²", Math.round(res.ukM2).toLocaleString() + " m²", "#1d4ed8"], ["Ukupno kg mat.", res.ukKg.toFixed(1) + " kg", "#059669"], ["m² po špulni", res.m2PerSpulna.toFixed(1) + " m²", "#64748b"], ["kg po špulni", res.kgPerSpulna.toFixed(2) + " kg", "#64748b"]].map(function (x) {
                                    return (
                                        <div key={x[0]} style={{ background: x[2] + "10", border: "1px solid " + x[2] + "30", borderRadius: 8, padding: "10px 12px" }}>
                                            <div style={{ fontSize: 9, color: "#64748b", fontWeight: 700, textTransform: "uppercase", marginBottom: 3 }}>{x[0]}</div>
                                            <div style={{ fontSize: 16, fontWeight: 800, color: x[2] }}>{x[1]}</div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                        <div style={card}>
                            <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 10 }}>📊 Struktura troškova</div>
                            {[["Materijal", res.ukMat], ["Transport", res.ukTr], ["Pakovanje", res.ukPk]].map(function (x) {
                                var pct = res.osn > 0 ? x[1] / res.osn * 100 : 0;
                                return (
                                    <div key={x[0]} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 7 }}>
                                        <div style={{ width: 120, fontSize: 12, color: "#64748b" }}>{x[0]}</div>
                                        <div style={{ flex: 1, height: 6, background: "#f1f5f9", borderRadius: 3, overflow: "hidden" }}>
                                            <div style={{ height: "100%", background: "#7c3aed", borderRadius: 3, width: Math.max(pct, 0.3) + "%" }} />
                                        </div>
                                        <div style={{ width: 80, textAlign: "right", fontSize: 12, fontWeight: 600 }}>{(+x[1]).toFixed(4).replace(".", ",")} €</div>
                                        <div style={{ width: 30, textAlign: "right", fontSize: 10, color: "#94a3b8" }}>{pct.toFixed(0)}%</div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                )
            )}
        </div>
    );
}

// ===================== PONUDE PAGE =====================

// ===================== PONUDE PAGE =====================
function PonudePage({ db, setDb, card, inp, lbl, eu, msg, user, pregPonuda, setPregPonuda, pdfLoading, pregPonudaRef, downloadPDF, kreirajNalogeIzPonude, odbijPonudu, setPage, TIP_BOJA, TIP_LAB }) {
    var [filterKupac, setFilterKupac] = useState("");
    var [filterStatus, setFilterStatus] = useState("");
    var [filterTip, setFilterTip] = useState("");
    var [pretraga, setPretraga] = useState("");
    var [brisanje, setBrisanje] = useState(null);

    var kupci = [...new Set(db.ponude.map(function (p) { return p.kupac; }).filter(Boolean))].sort();

    var filtrirane = db.ponude.filter(function (p) {
        return (!filterKupac || p.kupac === filterKupac) &&
            (!filterStatus || p.status === filterStatus) &&
            (!filterTip || p.tip === filterTip) &&
            (!pretraga || (p.naziv || "").toLowerCase().includes(pretraga.toLowerCase()) || (p.broj || "").toLowerCase().includes(pretraga.toLowerCase()));
    });

    var poKupcu = {};
    filtrirane.forEach(function (p) {
        var k = p.kupac || "—";
        if (!poKupcu[k]) poKupcu[k] = [];
        poKupcu[k].push(p);
    });

    async function obrisiPonudu(id) {
        try {
            var res = await supabase.from('ponude').delete().eq('id', id);
            if (res.error) throw res.error;
            setDb(function (d) { return Object.assign({}, d, { ponude: d.ponude.filter(function (p) { return p.id !== id; }) }); });
            setBrisanje(null);
            setPregPonuda(null);
            msg("Ponuda obrisana!");
        } catch (e) { msg("Greška: " + e.message, "err"); }
    }

    var stBg = function (s) { return s === "Aktivna" ? "#fef9c3" : s === "Odobrena" ? "#dcfce7" : "#fee2e2"; };
    var stCl = function (s) { return s === "Aktivna" ? "#854d0e" : s === "Odobrena" ? "#166534" : "#991b1b"; };

    if (brisanje) {
        return (
            <div style={{ position: "fixed", top: 0, left: 0, right: 0, bottom: 0, background: "rgba(0,0,0,0.5)", zIndex: 9999, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <div style={{ background: "#fff", borderRadius: 16, padding: 32, width: 380, textAlign: "center", boxShadow: "0 20px 60px rgba(0,0,0,0.3)" }}>
                    <div style={{ fontSize: 36, marginBottom: 12 }}>🗑️</div>
                    <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 8 }}>Obriši ponudu?</div>
                    <div style={{ fontSize: 13, color: "#64748b", marginBottom: 20 }}>Ponuda <b>{brisanje.broj}</b> za <b>{brisanje.kupac}</b> će biti trajno obrisana.</div>
                    <div style={{ display: "flex", gap: 10, justifyContent: "center" }}>
                        <button style={{ padding: "10px 24px", borderRadius: 8, border: "none", background: "#ef4444", color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer" }} onClick={function () { obrisiPonudu(brisanje.id); }}>Da, obriši</button>
                        <button style={{ padding: "10px 24px", borderRadius: 8, border: "1px solid #e2e8f0", background: "#fff", color: "#64748b", fontWeight: 700, fontSize: 13, cursor: "pointer" }} onClick={function () { setBrisanje(null); }}>Otkaži</button>
                    </div>
                </div>
            </div>
        );
    }

    if (pregPonuda) {
        return (
            <div>
                <div style={{ display: "flex", gap: 10, marginBottom: 14, flexWrap: "wrap", alignItems: "center" }}>
                    <button onClick={function () { setPregPonuda(null); }} style={{ padding: "8px 16px", borderRadius: 8, border: "1.5px solid #1d4ed8", background: "transparent", color: "#1d4ed8", cursor: "pointer", fontWeight: 700, fontSize: 13 }}>← Nazad</button>
                    <button style={{ padding: "8px 18px", borderRadius: 8, border: "none", background: "#dc2626", color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer", opacity: pdfLoading ? 0.7 : 1 }} onClick={function () { downloadPDF(pregPonudaRef, "Ponuda-" + (pregPonuda.broj || "")); }}>
                        {pdfLoading ? "⏳ Generišem..." : "⬇️ Preuzmi PDF"}
                    </button>
                    <button style={{ padding: "8px 18px", borderRadius: 8, border: "1px solid #fca5a5", background: "#fef2f2", color: "#ef4444", fontWeight: 700, fontSize: 13, cursor: "pointer" }} onClick={function () { setBrisanje(pregPonuda); }}>🗑️ Obriši</button>
                </div>
                <div style={card}>
                    <PonudaView printRef={pregPonudaRef} t={PREVODI[pregPonuda.jez || "sr"]} naziv={pregPonuda.naziv} kupac={pregPonuda.kupac} adr={pregPonuda.adr} kon={pregPonuda.kon} kol={pregPonuda.kol} c1={pregPonuda.c1} uk={pregPonuda.uk} nap={pregPonuda.nap} mats={pregPonuda.mats} broj={pregPonuda.broj} dat={pregPonuda.datum} vaz={pregPonuda.vaz} tip={pregPonuda.tip} />
                    {pregPonuda.status === "Aktivna" && (
                        <div style={{ marginTop: 18, paddingTop: 18, borderTop: "1px solid #e2e8f0", display: "flex", gap: 10 }}>
                            <button style={{ padding: "10px 18px", borderRadius: 8, border: "none", background: "#059669", color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer" }} onClick={function () { kreirajNalogeIzPonude(pregPonuda); }}>🔧 Odobri i kreiraj naloge</button>
                            <button style={{ padding: "10px 18px", borderRadius: 8, border: "none", background: "#ef4444", color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer" }} onClick={function () { odbijPonudu(pregPonuda.id); setPregPonuda(null); }}>✕ Odbij</button>
                        </div>
                    )}
                </div>
            </div>
        );
    }

    return (
        <div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
                <h2 style={{ margin: 0, fontSize: 20, fontWeight: 800 }}>📄 Ponude</h2>
                <div style={{ display: "flex", gap: 8 }}>
                    <button style={{ padding: "8px 14px", borderRadius: 7, border: "none", background: "#1d4ed8", color: "#fff", fontWeight: 700, fontSize: 12, cursor: "pointer" }} onClick={function () { setPage("kalk_folija"); }}>🧮 Nova folija</button>
                    <button style={{ padding: "8px 14px", borderRadius: 7, border: "none", background: "#059669", color: "#fff", fontWeight: 700, fontSize: 12, cursor: "pointer" }} onClick={function () { setPage("kalk_kesa"); }}>🛍️ Nova kesa</button>
                    <button style={{ padding: "8px 14px", borderRadius: 7, border: "none", background: "#7c3aed", color: "#fff", fontWeight: 700, fontSize: 12, cursor: "pointer" }} onClick={function () { setPage("kalk_spulna"); }}>🔄 Nova špulna</button>
                </div>
            </div>
            <div style={Object.assign({}, card, { marginBottom: 14, padding: "14px 16px" })}>
                <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
                    <input style={Object.assign({}, inp, { flex: 1, minWidth: 160 })} placeholder="🔍 Pretraži..." value={pretraga} onChange={function (e) { setPretraga(e.target.value); }} />
                    <select style={Object.assign({}, inp, { width: 170 })} value={filterKupac} onChange={function (e) { setFilterKupac(e.target.value); }}>
                        <option value="">👤 Svi kupci</option>
                        {kupci.map(function (k) { return <option key={k} value={k}>{k}</option>; })}
                    </select>
                    <select style={Object.assign({}, inp, { width: 140 })} value={filterStatus} onChange={function (e) { setFilterStatus(e.target.value); }}>
                        <option value="">📊 Svi statusi</option>
                        <option>Aktivna</option><option>Odobrena</option><option>Odbijena</option>
                    </select>
                    <select style={Object.assign({}, inp, { width: 130 })} value={filterTip} onChange={function (e) { setFilterTip(e.target.value); }}>
                        <option value="">🏷️ Svi tipovi</option>
                        <option value="folija">Folija</option><option value="kesa">Kesa</option><option value="spulna">Špulna</option>
                    </select>
                    {(filterKupac || filterStatus || filterTip || pretraga) && (
                        <button style={{ padding: "8px 12px", borderRadius: 7, border: "1px solid #e2e8f0", background: "#f8fafc", color: "#64748b", fontWeight: 700, fontSize: 12, cursor: "pointer" }} onClick={function () { setFilterKupac(""); setFilterStatus(""); setFilterTip(""); setPretraga(""); }}>✕ Reset</button>
                    )}
                </div>
            </div>
            {db.ponude.length === 0 ? (
                <div style={Object.assign({}, card, { textAlign: "center", padding: 50, color: "#94a3b8" })}>
                    <div style={{ fontSize: 36, marginBottom: 10 }}>📄</div>
                    <div>Nema ponuda.</div>
                </div>
            ) : (
                Object.keys(poKupcu).sort().map(function (kupac) {
                    var ponudeKupca = poKupcu[kupac];
                    var ukupno = ponudeKupca.reduce(function (s, p) { return s + (+p.uk || 0); }, 0);
                    return (
                        <div key={kupac} style={{ marginBottom: 16 }}>
                            <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 14px", background: "#0f172a", borderRadius: "10px 10px 0 0", color: "#fff" }}>
                                <span style={{ fontSize: 16 }}>👤</span>
                                <span style={{ fontWeight: 800, fontSize: 14 }}>{kupac}</span>
                                <span style={{ fontSize: 12, color: "#94a3b8", marginLeft: 4 }}>{ponudeKupca.length} ponuda</span>
                                <span style={{ marginLeft: "auto", fontWeight: 700, fontSize: 13, color: "#93c5fd" }}>{ukupno.toFixed(2).replace(".", ",")} €</span>
                            </div>
                            <div style={{ background: "#fff", borderRadius: "0 0 10px 10px", border: "1px solid #e2e8f0", borderTop: "none", overflow: "hidden" }}>
                                <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
                                    <thead><tr style={{ background: "#f8fafc", borderBottom: "1px solid #e2e8f0" }}>
                                        {["Broj", "Naziv", "Tip", "Kol.", "Ukupno", "Status", "Datum", ""].map(function (h) { return <th key={h} style={{ padding: "8px 10px", textAlign: "left", color: "#64748b", fontWeight: 600, fontSize: 11 }}>{h}</th>; })}
                                    </tr></thead>
                                    <tbody>
                                        {ponudeKupca.map(function (p) {
                                            return (
                                                <tr key={p.id} style={{ borderBottom: "1px solid #f1f5f9" }}>
                                                    <td style={{ padding: "9px 10px", fontWeight: 700, color: "#1d4ed8" }}>{p.broj}</td>
                                                    <td style={{ padding: "9px 10px", fontWeight: 600, fontSize: 12 }}>{p.naziv}</td>
                                                    <td style={{ padding: "9px 10px" }}><span style={{ background: (TIP_BOJA[p.tip] || "#64748b") + "20", color: TIP_BOJA[p.tip] || "#64748b", borderRadius: 6, padding: "2px 8px", fontWeight: 700, fontSize: 10 }}>{TIP_LAB[p.tip] || "—"}</span></td>
                                                    <td style={{ padding: "9px 10px", color: "#64748b" }}>{(p.kol || 0).toLocaleString()}</td>
                                                    <td style={{ padding: "9px 10px", fontWeight: 700, color: "#059669" }}>{eu(p.uk)}</td>
                                                    <td style={{ padding: "9px 10px" }}><span style={{ background: stBg(p.status), color: stCl(p.status), borderRadius: 6, padding: "2px 8px", fontWeight: 700, fontSize: 11 }}>{p.status}</span></td>
                                                    <td style={{ padding: "9px 10px", color: "#64748b", fontSize: 12 }}>{p.datum}</td>
                                                    <td style={{ padding: "9px 10px" }}>
                                                        <div style={{ display: "flex", gap: 5 }}>
                                                            <button style={{ padding: "4px 10px", borderRadius: 6, border: "none", background: "#1d4ed8", color: "#fff", cursor: "pointer", fontSize: 11, fontWeight: 700 }} onClick={function () { setPregPonuda(p); }}>👁️</button>
                                                            <button style={{ padding: "4px 10px", borderRadius: 6, border: "none", background: "#ef4444", color: "#fff", cursor: "pointer", fontSize: 11, fontWeight: 700 }} onClick={function () { setBrisanje(p); }}>🗑️</button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    );
                })
            )}
        </div>
    );
}

// ===================== BAZA PROIZVODA =====================
function BazaProizvoda({ db, setDb, card, inp, lbl, eu, msg, setPage, TIP_BOJA, TIP_LAB }) {
    var [filterKupac, setFilterKupac] = useState("");
    var [filterTip, setFilterTip] = useState("");
    var [pretraga, setPretraga] = useState("");

    var kupci = [...new Set(db.proizvodi.map(function (p) { return p.kupac; }).filter(Boolean))].sort();

    var filtrirani = db.proizvodi.filter(function (p) {
        return (!filterKupac || p.kupac === filterKupac) &&
            (!filterTip || p.tip === filterTip) &&
            (!pretraga || (p.naziv || "").toLowerCase().includes(pretraga.toLowerCase()));
    });

    var poKupcu = {};
    filtrirani.forEach(function (p) {
        var k = p.kupac || "Bez kupca";
        if (!poKupcu[k]) poKupcu[k] = [];
        poKupcu[k].push(p);
    });

    var BOJE = ["#1d4ed8", "#7c3aed", "#0891b2", "#059669"];
    var SLOJ = ["A", "B", "C", "D"];

    return (
        <div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
                <h2 style={{ margin: 0, fontSize: 20, fontWeight: 800 }}>📦 Baza proizvoda</h2>
                <div style={{ fontSize: 13, color: "#64748b", fontWeight: 600 }}>{filtrirani.length} / {db.proizvodi.length} proizvoda</div>
            </div>
            <div style={Object.assign({}, card, { marginBottom: 14, padding: "14px 16px" })}>
                <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
                    <input style={Object.assign({}, inp, { flex: 1, minWidth: 160 })} placeholder="🔍 Pretraži..." value={pretraga} onChange={function (e) { setPretraga(e.target.value); }} />
                    <select style={Object.assign({}, inp, { width: 170 })} value={filterKupac} onChange={function (e) { setFilterKupac(e.target.value); }}>
                        <option value="">👤 Svi kupci</option>
                        {kupci.map(function (k) { return <option key={k} value={k}>{k}</option>; })}
                    </select>
                    <select style={Object.assign({}, inp, { width: 140 })} value={filterTip} onChange={function (e) { setFilterTip(e.target.value); }}>
                        <option value="">🏷️ Svi tipovi</option>
                        <option value="folija">Folija</option><option value="kesa">Kesa</option><option value="spulna">Špulna</option>
                    </select>
                    {(filterKupac || filterTip || pretraga) && (
                        <button style={{ padding: "8px 12px", borderRadius: 7, border: "1px solid #e2e8f0", background: "#f8fafc", color: "#64748b", fontWeight: 700, fontSize: 12, cursor: "pointer" }} onClick={function () { setFilterKupac(""); setFilterTip(""); setPretraga(""); }}>✕ Reset</button>
                    )}
                </div>
            </div>
            {db.proizvodi.length === 0 ? (
                <div style={Object.assign({}, card, { textAlign: "center", padding: 50, color: "#94a3b8" })}>
                    <div style={{ fontSize: 36, marginBottom: 10 }}>📦</div>
                    <div style={{ marginBottom: 12 }}>Baza je prazna.</div>
                    <button style={{ padding: "10px 20px", borderRadius: 8, border: "none", background: "#1d4ed8", color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer" }} onClick={function () { setPage("kalk_folija"); }}>+ Nova kalkulacija</button>
                </div>
            ) : (
                Object.keys(poKupcu).sort().map(function (kupac) {
                    var proizvKupca = poKupcu[kupac];
                    return (
                        <div key={kupac} style={{ marginBottom: 16 }}>
                            <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 14px", background: "#0f172a", borderRadius: "10px 10px 0 0", color: "#fff" }}>
                                <span style={{ fontSize: 16 }}>👤</span>
                                <span style={{ fontWeight: 800, fontSize: 14 }}>{kupac}</span>
                                <span style={{ fontSize: 12, color: "#94a3b8", marginLeft: 4 }}>{proizvKupca.length} {proizvKupca.length === 1 ? "proizvod" : "proizvoda"}</span>
                            </div>
                            <div style={{ background: "#fff", borderRadius: "0 0 10px 10px", border: "1px solid #e2e8f0", borderTop: "none" }}>
                                {proizvKupca.map(function (p, pi) {
                                    var mats = (p.mats || []).filter(function (m) { return m.tip; });
                                    return (
                                        <div key={p.id} style={{ padding: "14px 16px", borderBottom: pi < proizvKupca.length - 1 ? "1px solid #f1f5f9" : "none", display: "flex", gap: 14, alignItems: "flex-start" }}>
                                            <span style={{ background: (TIP_BOJA[p.tip] || "#64748b") + "20", color: TIP_BOJA[p.tip] || "#64748b", borderRadius: 6, padding: "3px 10px", fontWeight: 700, fontSize: 10, flexShrink: 0, marginTop: 2 }}>{TIP_LAB[p.tip] || "—"}</span>
                                            <div style={{ flex: 1 }}>
                                                <div style={{ fontWeight: 800, fontSize: 14, marginBottom: 4 }}>{p.naziv}</div>
                                                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                                                    {mats.map(function (m, i) {
                                                        return (
                                                            <span key={i} style={{ fontSize: 11, background: BOJE[i] + "15", color: BOJE[i], borderRadius: 5, padding: "2px 7px", fontWeight: 700 }}>
                                                                {SLOJ[i]}: {m.tip} {m.deb}µ
                                                            </span>
                                                        );
                                                    })}
                                                    {p.sir && <span style={{ fontSize: 11, color: "#64748b", padding: "2px 7px", background: "#f1f5f9", borderRadius: 5 }}>📏 {p.sir}mm</span>}
                                                </div>
                                            </div>
                                            {p.res && p.res.k1 && (
                                                <div style={{ textAlign: "right", flexShrink: 0 }}>
                                                    <div style={{ fontSize: 11, color: "#64748b", marginBottom: 2 }}>Cena/1000m</div>
                                                    <div style={{ fontSize: 18, fontWeight: 800, color: "#1d4ed8" }}>{eu(p.res.k1)}</div>
                                                </div>
                                            )}
                                            <div style={{ display: "flex", flexDirection: "column", gap: 5, flexShrink: 0 }}>
                                                <button style={{ padding: "5px 12px", borderRadius: 6, border: "none", background: "#1d4ed8", color: "#fff", cursor: "pointer", fontSize: 11, fontWeight: 700 }} onClick={function () {
                                                    if (p.tip === "kesa") setPage("kalk_kesa");
                                                    else if (p.tip === "spulna") setPage("kalk_spulna");
                                                    else setPage("kalk_folija");
                                                }}>📋 Otvori kalk.</button>
                                                <button style={{ padding: "5px 12px", borderRadius: 6, border: "none", background: "#059669", color: "#fff", cursor: "pointer", fontSize: 11, fontWeight: 700 }} onClick={function () { setPage("novi_nalog_izbor"); }}>⚡ Kreiraj nalog</button>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    );
                })
            )}
        </div>
    );
}

// ===================== MOBILNA STRANICA ZA RADNIKE =====================
var ZASTOJI = [
    { k: "Pauza za ručak", kat: "Planirani", i: "🍽️" },
    { k: "Kratka pauza", kat: "Planirani", i: "☕" },
    { k: "Promena smene", kat: "Planirani", i: "🔄" },
    { k: "Kvar mašine", kat: "Tehnički", i: "⚙️" },
    { k: "Održavanje mašine", kat: "Tehnički", i: "🧰" },
    { k: "Promena podešavanja", kat: "Tehnički", i: "🔧" },
    { k: "Nestanak struje/vazduha", kat: "Tehnički", i: "⚡" },
    { k: "Nema materijala", kat: "Materijal", i: "📦" },
    { k: "Nema boje", kat: "Materijal", i: "🎨" },
    { k: "Zamena rolne", kat: "Materijal", i: "🔁" },
    { k: "Loš materijal", kat: "Materijal", i: "⚠️" },
    { k: "Čeka prethodni nalog", kat: "Priprema", i: "📋" },
    { k: "Testiranje uzorka", kat: "Priprema", i: "🧪" },
    { k: "Kalibracija", kat: "Priprema", i: "🎯" },
    { k: "Kontrola kvaliteta", kat: "Kvalitet", i: "🔍" },
    { k: "Dorada", kat: "Kvalitet", i: "♻️" },
    { k: "Ostalo", kat: "Ostalo", i: "📝" },
];

function MobilniRadnik({ nalogId }) {
    var [nalog, setNalog] = useState(null);
    var [status, setStatus] = useState("ceka");
    var [startTime, setStartTime] = useState(null);
    var [elapsed, setElapsed] = useState(0);
    var [pauzeVreme, setPauzeVreme] = useState(0);
    var [pauzeStart, setPauzeStart] = useState(null);
    var [pauzeRazlog, setPauzeRazlog] = useState("");
    var [pauzeNapomena, setPauzeNapomena] = useState("");
    var [uradjeno, setUradjeno] = useState("");
    var [skart, setSkart] = useState("");
    var [radnik, setRadnik] = useState("");
    var [loading, setLoading] = useState(true);
    var [birePazu, setBirePazu] = useState(false);

    var IKONE = { "Nalog za materijal": "📦", "Nalog za stampu": "🖨️", "Nalog za kasiranje": "🔗", "Nalog za rezanje": "✂️", "Nalog za perforaciju": "🔵", "Nalog za lakiranje": "✨", "Nalog za spulne": "🔄" };

    useEffect(function () {
        supabase.from('nalozi').select('*').eq('id', nalogId).single().then(function (r) {
            if (r.data) setNalog(r.data);
            setLoading(false);
        });
    }, [nalogId]);

    useEffect(function () {
        if (status !== "u_toku" || !startTime) return;
        var t = setInterval(function () {
            setElapsed(Math.floor((Date.now() - new Date(startTime).getTime()) / 1000) - pauzeVreme);
        }, 1000);
        return function () { clearInterval(t); };
    }, [status, startTime, pauzeVreme]);

    async function pocni() {
        var now = new Date().toISOString();
        setStartTime(now);
        setStatus("u_toku");
        await supabase.from('nalozi').update({ status: "U toku", radnik: radnik, start_time: now }).eq('id', nalogId);
    }

    function kliknutaPauza() {
        setBirePazu(true);
    }

    async function potvrdiPauzu(razlogObj) {
        var now = Date.now();
        setPauzeStart(now);
        setPauzeRazlog(razlogObj.k);
        setStatus("pauza");
        setBirePazu(false);
        // Snimi zastoj u bazu
        try {
            await supabase.from('nalog_zastoji').insert([{
                nalog_id: +nalogId,
                razlog: razlogObj.k,
                kategorija: razlogObj.kat,
                start_time: new Date(now).toISOString(),
                radnik: radnik || "nepoznat",
                napomena: pauzeNapomena
            }]);
        } catch (e) { console.error(e); }
    }

    async function nastavi() {
        var now = Date.now();
        var dodatno = Math.floor((now - pauzeStart) / 1000);
        setPauzeVreme(function (p) { return p + dodatno; });
        // Update zastoj u bazi
        try {
            var res = await supabase.from('nalog_zastoji')
                .select('id')
                .eq('nalog_id', +nalogId)
                .is('end_time', null)
                .order('id', { ascending: false })
                .limit(1);
            if (res.data && res.data[0]) {
                await supabase.from('nalog_zastoji').update({
                    end_time: new Date(now).toISOString(),
                    trajanje: dodatno
                }).eq('id', res.data[0].id);
            }
        } catch (e) { console.error(e); }
        setPauzeStart(null);
        setPauzeRazlog("");
        setPauzeNapomena("");
        setStatus("u_toku");
    }

    async function zavrsi() {
        if (!uradjeno) { alert("Unesite količinu!"); return; }
        var now = new Date().toISOString();
        await supabase.from('nalozi').update({
            status: "Završeno",
            end_time: now,
            vreme_rada: elapsed,
            uradjeno: +uradjeno,
            skart: +skart || 0
        }).eq('id', nalogId);
        setStatus("zavrseno");
    }

    var fmt = function (s) { var h = Math.floor(s / 3600); var m = Math.floor((s % 3600) / 60); var sec = s % 60; return String(h).padStart(2, "0") + ":" + String(m).padStart(2, "0") + ":" + String(sec).padStart(2, "0"); };

    if (loading) return <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "sans-serif", color: "#94a3b8" }}>⏳ Učitavam...</div>;
    if (!nalog) return <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "sans-serif", color: "#ef4444" }}>❌ Nalog nije pronađen!</div>;

    var ik = IKONE[nalog.naziv] || "🔧";

    // ---- IZBOR RAZLOGA PAUZE ----
    if (birePazu) {
        var grupirani = {};
        ZASTOJI.forEach(function (z) {
            if (!grupirani[z.kat]) grupirani[z.kat] = [];
            grupirani[z.kat].push(z);
        });
        var katBoje = { "Planirani": "#8b5cf6", "Tehnički": "#ef4444", "Materijal": "#f59e0b", "Priprema": "#0891b2", "Kvalitet": "#ec4899", "Ostalo": "#64748b" };
        return (
            <div style={{ minHeight: "100vh", background: "#f8fafc", fontFamily: "'Segoe UI',system-ui,sans-serif", padding: 16, maxWidth: 420, margin: "0 auto" }}>
                <div style={{ background: "#fef3c7", borderRadius: 12, padding: 14, marginBottom: 14, border: "2px solid #fde68a", textAlign: "center" }}>
                    <div style={{ fontSize: 24, marginBottom: 4 }}>⏸️</div>
                    <div style={{ fontSize: 15, fontWeight: 800, color: "#92400e" }}>Razlog pauze/zastoja</div>
                    <div style={{ fontSize: 12, color: "#78716c", marginTop: 2 }}>Izaberi razlog za nastavak</div>
                </div>
                {Object.keys(grupirani).map(function (kat) {
                    return (
                        <div key={kat} style={{ marginBottom: 14 }}>
                            <div style={{ fontSize: 11, fontWeight: 800, color: katBoje[kat], textTransform: "uppercase", marginBottom: 6, paddingLeft: 4, letterSpacing: 0.5 }}>{kat}</div>
                            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
                                {grupirani[kat].map(function (z) {
                                    return (
                                        <button key={z.k} onClick={function () { potvrdiPauzu(z); }}
                                            style={{ padding: "12px 10px", borderRadius: 10, border: "1.5px solid " + katBoje[kat] + "40", background: "#fff", color: "#1e293b", fontWeight: 700, fontSize: 11, cursor: "pointer", textAlign: "left", display: "flex", alignItems: "center", gap: 8 }}>
                                            <span style={{ fontSize: 20 }}>{z.i}</span>
                                            <span>{z.k}</span>
                                        </button>
                                    );
                                })}
                            </div>
                        </div>
                    );
                })}
                <button onClick={function () { setBirePazu(false); }} style={{ width: "100%", marginTop: 10, padding: 14, borderRadius: 10, border: "1px solid #e2e8f0", background: "#fff", color: "#64748b", fontWeight: 700, fontSize: 13, cursor: "pointer" }}>← Otkaži</button>
            </div>
        );
    }

    return (
        <div style={{ minHeight: "100vh", background: status === "u_toku" ? "#f0fdf4" : status === "pauza" ? "#fffbeb" : "#f8fafc", fontFamily: "'Segoe UI',system-ui,sans-serif", padding: 20, maxWidth: 420, margin: "0 auto" }}>
            <div style={{ background: "#0f172a", borderRadius: 14, padding: "14px 18px", marginBottom: 16, color: "#fff" }}>
                <div style={{ fontSize: 11, color: "#94a3b8", marginBottom: 4 }}>Radni nalog</div>
                <div style={{ fontSize: 20, fontWeight: 800 }}>{nalog.ponBr}</div>
                <div style={{ fontSize: 14, color: "#93c5fd", marginTop: 2 }}>{nalog.kupac} · {nalog.prod}</div>
            </div>

            <div style={{ background: "#fff", borderRadius: 12, padding: 16, border: "1px solid #e2e8f0", marginBottom: 14, textAlign: "center" }}>
                <div style={{ fontSize: 40, marginBottom: 8 }}>{ik}</div>
                <div style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>{nalog.naziv}</div>
                <div style={{ fontSize: 14, color: "#64748b" }}>Količina: <b>{(nalog.kol || 0).toLocaleString()} m</b></div>
            </div>

            {status === "ceka" && (
                <div>
                    <div style={{ marginBottom: 12 }}>
                        <label style={{ fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Tvoje ime (opciono)</label>
                        <input value={radnik} onChange={function (e) { setRadnik(e.target.value); }} style={{ width: "100%", padding: "12px 16px", borderRadius: 10, border: "1.5px solid #e2e8f0", fontSize: 16, outline: "none", boxSizing: "border-box" }} placeholder="npr. Milan" />
                    </div>
                    <button onClick={pocni} style={{ width: "100%", padding: 20, borderRadius: 16, border: "none", background: "#059669", color: "#fff", fontSize: 22, fontWeight: 800, cursor: "pointer" }}>▶️ POČNI RAD</button>
                </div>
            )}

            {status === "u_toku" && (
                <div>
                    <div style={{ background: "#dcfce7", borderRadius: 14, padding: 20, textAlign: "center", marginBottom: 14, border: "2px solid #bbf7d0" }}>
                        <div style={{ fontSize: 12, fontWeight: 700, color: "#64748b", textTransform: "uppercase", marginBottom: 8 }}>⏱️ U TOKU</div>
                        <div style={{ fontSize: 52, fontWeight: 900, color: "#059669", fontVariantNumeric: "tabular-nums" }}>{fmt(elapsed)}</div>
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 10 }}>
                        <button onClick={kliknutaPauza} style={{ padding: 18, borderRadius: 12, border: "none", background: "#f59e0b", color: "#fff", fontSize: 16, fontWeight: 800, cursor: "pointer" }}>⏸️ PAUZA</button>
                        <button onClick={function () { setStatus("unos"); }} style={{ padding: 18, borderRadius: 12, border: "none", background: "#1d4ed8", color: "#fff", fontSize: 16, fontWeight: 800, cursor: "pointer" }}>⏹️ ZAVRŠI</button>
                    </div>
                </div>
            )}

            {status === "pauza" && (
                <div>
                    <div style={{ background: "#fef3c7", borderRadius: 14, padding: 20, textAlign: "center", marginBottom: 14, border: "2px solid #fde68a" }}>
                        <div style={{ fontSize: 12, fontWeight: 700, color: "#92400e", textTransform: "uppercase", marginBottom: 4 }}>⏸️ PAUZA</div>
                        <div style={{ fontSize: 14, fontWeight: 700, color: "#92400e", marginBottom: 8 }}>{pauzeRazlog}</div>
                        <div style={{ fontSize: 52, fontWeight: 900, color: "#f59e0b", fontVariantNumeric: "tabular-nums" }}>{fmt(elapsed)}</div>
                    </div>
                    <button onClick={nastavi} style={{ width: "100%", padding: 18, borderRadius: 12, border: "none", background: "#059669", color: "#fff", fontSize: 18, fontWeight: 800, cursor: "pointer" }}>▶️ NASTAVI RAD</button>
                </div>
            )}

            {status === "unos" && (
                <div style={{ background: "#fff", borderRadius: 14, padding: 20, border: "1px solid #e2e8f0" }}>
                    <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>📊 Unesi rezultate</div>
                    <div style={{ marginBottom: 12 }}>
                        <label style={{ fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Urađena količina (m) *</label>
                        <input type="number" value={uradjeno} onChange={function (e) { setUradjeno(e.target.value); }} style={{ width: "100%", padding: "14px 16px", borderRadius: 10, border: "2px solid #1d4ed8", fontSize: 22, fontWeight: 700, outline: "none", boxSizing: "border-box" }} placeholder="0" />
                    </div>
                    <div style={{ marginBottom: 16 }}>
                        <label style={{ fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Škart (m)</label>
                        <input type="number" value={skart} onChange={function (e) { setSkart(e.target.value); }} style={{ width: "100%", padding: "12px 16px", borderRadius: 10, border: "1.5px solid #e2e8f0", fontSize: 18, outline: "none", boxSizing: "border-box" }} placeholder="0" />
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                        <button onClick={function () { setStatus("u_toku"); }} style={{ padding: 14, borderRadius: 10, border: "1px solid #e2e8f0", background: "#f8fafc", color: "#64748b", fontSize: 14, fontWeight: 700, cursor: "pointer" }}>← Nazad</button>
                        <button onClick={zavrsi} style={{ padding: 14, borderRadius: 10, border: "none", background: "#059669", color: "#fff", fontSize: 14, fontWeight: 700, cursor: "pointer" }}>✅ Potvrdi</button>
                    </div>
                </div>
            )}

            {status === "zavrseno" && (
                <div style={{ background: "#f0fdf4", borderRadius: 14, padding: 28, border: "2px solid #bbf7d0", textAlign: "center" }}>
                    <div style={{ fontSize: 56, marginBottom: 12 }}>✅</div>
                    <div style={{ fontSize: 22, fontWeight: 800, color: "#166534", marginBottom: 10 }}>Završeno!</div>
                    <div style={{ fontSize: 14, color: "#064e3b", marginBottom: 4 }}>Vreme rada: <b>{fmt(elapsed)}</b></div>
                    <div style={{ fontSize: 14, color: "#064e3b", marginBottom: 4 }}>Urađeno: <b>{(+uradjeno).toLocaleString()} m</b></div>
                    {+skart > 0 && <div style={{ fontSize: 14, color: "#ef4444" }}>Škart: <b>{(+skart).toLocaleString()} m</b></div>}
                </div>
            )}
        </div>
    );
}

// Mobilna stranica za radnike - pronalazi nalog po ponBr+suffix
function MobilniRadnikPonBr({ ponBr }) {
    var [nalogId, setNalogId] = useState(null);
    var [greska, setGreska] = useState(false);

    useEffect(function () {
        supabase.from('nalozi').select('id').eq('ponBr', ponBr).single()
            .then(function (r) {
                if (r.data) setNalogId(r.data.id);
                else {
                    // Try matching ponBr prefix (e.g. MP-2026-1042 matches MP-2026-1042-7)
                    var base = ponBr.replace(/-\d+$/, '');
                    supabase.from('nalozi').select('id').eq('ponBr', base).limit(1)
                        .then(function (r2) {
                            if (r2.data && r2.data[0]) setNalogId(r2.data[0].id);
                            else setGreska(true);
                        });
                }
            });
    }, [ponBr]);

    if (greska) return <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "sans-serif", flexDirection: "column", gap: 12 }}><div style={{ fontSize: 48 }}>❌</div><div style={{ color: "#ef4444", fontWeight: 700 }}>Nalog nije pronađen: {ponBr}</div></div>;
    if (!nalogId) return <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "sans-serif", color: "#94a3b8" }}>⏳ Učitavam nalog...</div>;
    return <MobilniRadnik nalogId={nalogId} />;
}

// ============================================
// GLAVNA APLIKACIJA SA AUTH SISTEMOM
// ============================================
function MainAppContent() {
    // ✅ AUTH HOOK - dobija user info
    const { user, userProfile, signOut, isAdmin, isManager, isMagacioner, canEdit } = useAuth();

    // ✅ PROFESIONALNI NALOZI
    // Jedan glavni prikaz naloga: PregledNalogaPRO. Nema više paralelnog starog print layout-a.

    // ---- MAGACIN QR SCANNER (QR skeniranje rolni) ----
    var urlParams = new URLSearchParams(window.location.search);
    var rolnaQR = urlParams.get("rolna"); // ?rolna=R-2026-001
    var nalogQR = urlParams.get("nalog"); // ?nalog=MP-2026-0001
    var opQR = urlParams.get("opid"); // ?opid=<id operacije> → radnička strana


    if (rolnaQR) {
        return <MobilniMagacin brRolne={rolnaQR} />;
    }

    if (opQR) {
        return <RadnikOperacija opid={opQR} />;
    }

    if (nalogQR) {
        return <PregledNalogaPRO brojNaloga={nalogQR} osnovniNalog={{ ponBr: nalogQR }} />;
    }
    // -----------------------------------------------------

    const [page, setPage] = useState("dashboard_pro");
    const [openGroups, setOpenGroups] = useState(['dashboard']);
    const [navOtvoren, setNavOtvoren] = useState(false);   // mobilni meni (hamburger)
    const [isMobileViewport, setIsMobileViewport] = useState(() => {
        if (typeof window === "undefined") return false;
        return window.innerWidth < 768;
    });

    useEffect(function () {
        function handleResize() {
            setIsMobileViewport(window.innerWidth < 768);
        }
        handleResize();
        window.addEventListener("resize", handleResize);
        window.addEventListener("orientationchange", handleResize);
        return function () {
            window.removeEventListener("resize", handleResize);
            window.removeEventListener("orientationchange", handleResize);
        };
    }, []);

    useEffect(function () {
        if (isMagacioner || userProfile?.uloga === "radnik") {
            setPage("rolne_engine");
            setOpenGroups(["magacin"]);
        }
    }, [isMagacioner, userProfile?.uloga]); // ✅ ACCORDION STATE
    const [db, setDb] = useState({ proizvodi: [], ponude: [], nalozi: [], master_nalozi: [], rolne: [], masine: [], radnici: [], production_sessions: [], qc_zapisnici: [] });
    const [notif, setNotif] = useState(null);
    const [lIme, setLIme] = useState("");
    const [lPass, setLPass] = useState("");
    const [lErr, setLErr] = useState("");
    const [pregNalog, setPregNalog] = useState(null);
    const [pregPonuda, setPregPonuda] = useState(null);
    const [stampa, setStampa] = useState(null);
    const [uploading, setUploading] = useState(null);
    const [pdfLoading, setPdfLoading] = useState(false);

    const pregPonudaRef = useRef(null);

    const msg = useCallback(function (m, t) { setNotif({ msg: m, tip: t || "ok" }); setTimeout(function () { setNotif(null); }, 3000); }, []);


    // ========================================================================
    // LEGACY KOMPATIBILNOST: dugme "Prihvati ponudu" sada koristi PRO tok
    // Kalkulacija -> Ponuda -> Profesionalni radni nalozi
    // ========================================================================
    async function handlePrihvatiPonudu(ponuda) {
        return kreirajNalogeIzPonude(ponuda);
    }

    async function downloadPDF(ref, filename) {
        if (!ref.current) return;
        setPdfLoading(true);
        try { const canvas = await html2canvas(ref.current, { scale: 2, useCORS: true, backgroundColor: "#ffffff" }); const imgData = canvas.toDataURL("image/png"); const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" }); const pdfW = pdf.internal.pageSize.getWidth(); const pdfH = (canvas.height * pdfW) / canvas.width; pdf.addImage(imgData, "PNG", 0, 0, pdfW, pdfH); pdf.save(filename + ".pdf"); msg("PDF preuzet!"); }
        catch (e) { msg("Greska PDF", "err"); }
        setPdfLoading(false);
    }

    const loadDataRef = useRef(null);
    useEffect(function () {
        if (!user) return;
        async function loadData() {
            try {
                let core = { proizvodi: [], ponude: [], nalozi: [], master_nalozi: [], rolne: [], masine: [], radnici: [], production_sessions: [], qc_zapisnici: [] };
                try {
                    core = await fetchCoreData();
                } catch (coreError) {
                    console.warn("Supabase Core tabele nisu dostupne ili RLS blokira čitanje, podaci iz baze nisu dostupni:", coreError.message);
                }

                setDb({
                    proizvodi: core.proizvodi || [],
                    ponude: core.ponude || [],
                    nalozi: core.nalozi || [],
                    master_nalozi: core.master_nalozi || [],
                    rolne: core.rolne || [],
                    masine: core.masine || [],
                    radnici: core.radnici || [],
                    production_sessions: core.production_sessions || [],
                    qc_zapisnici: core.qc_zapisnici || []
                });
            } catch (e) { console.error(e); }
        }
        loadDataRef.current = loadData;
        loadData();

        // fetchCoreData() cita DEVET tabela odjednom (magacin ima 1000+ redova).
        // Realtime ume da posalje vise dogadjaja u nizu (npr. rezervacija vise rolni
        // za jedan nalog), pa se to ranije pretvaralo u vise punih preucitavanja
        // zaredom — otud sporo kreiranje naloga. Sada se sazimaju u jedno.
        let debounceTimer = null;
        const loadDataDebounced = function () {
            if (debounceTimer) clearTimeout(debounceTimer);
            debounceTimer = setTimeout(function () { debounceTimer = null; loadData(); }, 400);
        };

        const ch = supabase.channel('maropack-changes')
            .on('postgres_changes', { event: '*', schema: 'public', table: 'proizvodi' }, loadDataDebounced)
            .on('postgres_changes', { event: '*', schema: 'public', table: 'ponude' }, loadDataDebounced)
            .on('postgres_changes', { event: '*', schema: 'public', table: 'nalozi' }, loadDataDebounced)
            .on('postgres_changes', { event: '*', schema: 'public', table: 'radni_nalozi' }, loadDataDebounced)
            .on('postgres_changes', { event: '*', schema: 'public', table: 'operativni_nalozi' }, loadDataDebounced)
            .on('postgres_changes', { event: '*', schema: 'public', table: 'master_nalozi' }, loadDataDebounced)
            .on('postgres_changes', { event: '*', schema: 'public', table: 'rolne' }, loadDataDebounced)
            .on('postgres_changes', { event: '*', schema: 'public', table: 'production_sessions' }, loadDataDebounced)
            .subscribe();

        // ProductTemplateEngine emituje ovaj dogadjaj kad napravi nalog, ali ga do sada
        // niko nije slusao — pa se nov nalog nije video dok se cela aplikacija ne osvezi.
        // Ovo radi i kad realtime replikacija za radni_nalozi/operativni_nalozi
        // nije ukljucena u Supabase (Database → Replication).
        const onNaloziChanged = function () { loadData(); };
        window.addEventListener("maropack:nalozi-changed", onNaloziChanged);
        // Povratak u tab / na telefon posle rada u drugoj aplikaciji.
        const onFocus = function () { if (document.visibilityState === "visible") loadDataDebounced(); };
        document.addEventListener("visibilitychange", onFocus);

        return function () {
            if (debounceTimer) clearTimeout(debounceTimer);
            supabase.removeChannel(ch);
            window.removeEventListener("maropack:nalozi-changed", onNaloziChanged);
            document.removeEventListener("visibilitychange", onFocus);
        };
    }, [user]);

    async function updN(id, f, v) {
        try { const { error } = await supabase.from('nalozi').update({ [f]: v }).eq('id', id); if (error) throw error; }
        catch (e) { msg("Greska: " + e.message, "err"); }
    }

    async function uploadFajl(nalogId, tipFajla, file) {
        if (!file) return;
        setUploading(nalogId + "_" + tipFajla);
        try {
            const ext = file.name.split('.').pop();
            const path = "nalog_" + nalogId + "/" + tipFajla + "_" + Date.now() + "." + ext;
            const { error: upErr } = await supabase.storage.from('maropack-files').upload(path, file); if (upErr) throw upErr;
            const { data: urlData } = supabase.storage.from('maropack-files').getPublicUrl(path);
            const url = urlData.publicUrl;
            const kolona = "link_" + tipFajla;
            const { error: dbErr } = await supabase.from('nalozi').update({ [kolona]: url }).eq('id', nalogId); if (dbErr) throw dbErr;
            msg("Fajl uploadovan!");
        } catch (e) { msg("Greska upload: " + e.message, "err"); }
        setUploading(null);
    }

    async function obrisiFajl(nalogId, tipFajla) {
        try { const { error } = await supabase.from('nalozi').update({ ["link_" + tipFajla]: null }).eq('id', nalogId); if (error) throw error; msg("Fajl obrisan"); }
        catch (e) { msg("Greska: " + e.message, "err"); }
    }

    async function odbijPonudu(id) {
        try { const { error } = await supabase.from('ponude').update({ status: "Odbijena" }).eq('id', id); if (error) throw error; msg("Ponuda odbijena"); }
        catch (e) { msg("Greska: " + e.message, "err"); }
    }

    function normalizujTipProizvoda(tip) {
        var t = String(tip || "folija").toLowerCase();
        if (t === "špulna") return "spulna";
        if (t.includes("spul")) return "spulna";
        if (t.includes("kes")) return "kesa";
        return "folija";
    }

    function osnovniBrojPonude(pon) {
        return pon.ponBr || pon.broj || pon.broj_ponude || pon.broj_naloga || ("RN-" + new Date().getFullYear() + "-" + String(pon.id || Date.now()).padStart(4, "0"));
    }

    async function dodeliRolneZaNalog(broj, pon) {
        try {
            if (!broj) return { assigned: 0, manjak: [] };
            const tpl = extractTemplate(pon) || {};
            const folija = tpl.folija || (tpl.data && tpl.data.folija) || pon.folija || {};
            let layers = (folija.layers && folija.layers.length) ? folija.layers
                : (Array.isArray(pon.mats) && pon.mats.length ? pon.mats
                    : (Array.isArray(pon.struktura) ? pon.struktura : []));
            if (!layers || !layers.length) return { assigned: 0, manjak: [] };
            const kolicina = Number(pon.kol || pon.kolicina || 0) || 0;
            const idealna = Number(folija.idealnaSirinaMaterijala || tpl.idealnaSirinaMaterijala || 0) || 0;
            let assigned = 0; const manjak = [];
            for (const l of layers) {
                const vrsta = l.vrsta || l.materijal || l.tip || "";
                if (!vrsta) continue;
                const oznaka = l.oznaka_materijala || l.oznaka || "";
                const deb = Number(String(l.debljina ?? l.deb ?? "").toString().replace(",", ".")) || 0;
                const sirina = Number(l.sirina || idealna || 0) || 0;
                const gm2 = Number(l.gm2 || l.tezina || 0) || 0;
                const needKg = Number(l.kg || 0) || (gm2 && kolicina && sirina ? gm2 * (kolicina / 1000) * (sirina / 1000) : 0);
                let rows = [];
                try {
                    const { data } = await supabase.from("magacin")
                        .select("id,kg_neto,kg_bruto,metraza_ost,oznaka_materijala,deb,vrsta,dodeljeno_nalogu,status,datum_proizvodnje")
                        .eq("status", "Na stanju").ilike("vrsta", "%" + vrsta + "%")
                        .order("datum_proizvodnje", { ascending: true }).limit(80);
                    rows = (data || []).filter((r) => !r.dodeljeno_nalogu);
                } catch (e) { rows = []; }
                if (oznaka) { const ex = rows.filter((r) => String(r.oznaka_materijala || "").toUpperCase().includes(String(oznaka).toUpperCase())); if (ex.length) rows = ex; }
                if (deb) { const ex = rows.filter((r) => Number(r.deb || 0) === deb); if (ex.length) rows = ex; }
                const chosen = []; let acc = 0;
                for (const r of rows) {
                    chosen.push(r.id);
                    acc += Number(r.kg_neto || r.kg_bruto || 0) || 0;
                    if (needKg > 0 ? acc >= needKg : true) break;
                }
                if (chosen.length) {
                    try { await supabase.from("magacin").update({ dodeljeno_nalogu: broj, rezervisano: true }).in("id", chosen); assigned += chosen.length; } catch (e) { }
                }
                if (needKg > 0 && acc < needKg) manjak.push(vrsta + (oznaka ? " " + oznaka : ""));
                if (!chosen.length) manjak.push(vrsta + (oznaka ? " " + oznaka : ""));
            }
            return { assigned, manjak };
        } catch (e) { console.warn("Auto-dodela rolni:", e.message || e); return { assigned: 0, manjak: [] }; }
    }

    async function kreirajNalogeIzPonude(pon) {
        if (!pon) { msg("Ponuda nije pronađena", "err"); return; }
        if (!pon.id) { msg("Ponuda nije sačuvana u bazi (nema ID). Sačuvaj ponudu pa pokušaj ponovo.", "err"); return; }

        // Jedini izvor istine: SQL RPC kreiraj_naloge_iz_ponude -> radni_nalozi + operativni_nalozi.
        try {
            const rpcResult = await generateMasterFromPonuda(pon);
            if (rpcResult.usedRpc && !rpcResult.error) {
                try { await supabase.from('ponude').update({ status: "prihvaceno" }).eq('id', pon.id); } catch (e) { }
                // Master broj iz radni_nalozi (isti broj koji magacioner/nalog koriste)
                var broj = (rpcResult.data && (rpcResult.data.broj_naloga || rpcResult.data.broj)) || "";
                try { const { data: mr } = await supabase.from("radni_nalozi").select("broj_naloga").eq("ponuda_id", pon.id).order("created_at", { ascending: false }).limit(1); if (mr && mr[0] && mr[0].broj_naloga) broj = mr[0].broj_naloga; } catch (e) { }
                // Auto-dodela rolni iz magacina po slojevima templejta
                var dod = await dodeliRolneZaNalog(broj, pon);
                try { if (loadDataRef.current) await loadDataRef.current(); } catch (e) { }
                var brNal = broj || "";
                msg("Nalozi kreirani" + (brNal ? " · " + brNal : "") + (dod && dod.assigned ? " · dodeljeno " + dod.assigned + " rolni" : "") + (dod && dod.manjak && dod.manjak.length ? " · MANJAK: " + dod.manjak.join(", ") : "") + ". Otvaram glavne naloge.");
                setPregPonuda(null);
                setPage("nalozi");
                return;
            }
            var rpcErr = (rpcResult.error && rpcResult.error.message) || "Nepoznata greška.";
            msg("Naloge nije moguće kreirati: " + rpcErr, "err");
            return;
        } catch (rpcFatal) {
            msg("Greška pri kreiranju naloga: " + (rpcFatal.message || rpcFatal), "err");
            return;
        }

        var vm = Array.isArray(pon.mats) ? pon.mats : (Array.isArray(pon.struktura) ? pon.struktura : []);
        var brKas = vm.reduce(function (s, m) { return s + (+m.kas || +m.kasiranje || 0); }, 0);
        var brLak = vm.reduce(function (s, m) { return s + (+m.lak || +m.lakiranje || 0); }, 0);
        var hasSt = vm.some(function (m) { return !!(m.stamp || m.stampa || m.stampanje); });
        var tipProizvoda = normalizujTipProizvoda(pon.tip || pon.tip_proizvoda || pon.vrsta || "folija");
        var broj = osnovniBrojPonude(pon);
        var nazivProizvoda = pon.prod || pon.proizvod || pon.naziv || "Proizvod";
        var kupac = pon.kupac || pon.klijent || "Kupac";
        var kol = pon.kol || pon.kolicina || pon.količina || 0;
        var masterId = "MASTER-" + String(broj).replace(/[^a-zA-Z0-9_-]/g, "-");
        var linkedBase = buildOrderSourcePack({ ponuda: pon, tipOperacije: 'master', tipProizvoda: tipProizvoda });
        var templatePayload = linkedBase.product_template || extractTemplate(pon);
        var kalkulacijaPayload = linkedBase.kalkulacija_payload || extractKalkulacija(pon);
        var masterNalog = {
            id: masterId,
            master_nalog_id: masterId,
            broj_naloga: broj,
            ponBr: broj,
            master_broj: broj,
            ponuda_id: pon.id || pon.ponuda_id || null,
            kalkulacija_id: pon.kalkulacija_id || pon.kalkulacije_id || null,
            tip: tipProizvoda,
            tip_proizvoda: tipProizvoda,
            kupac: kupac,
            prod: nazivProizvoda,
            proizvod: nazivProizvoda,
            kol: kol,
            kolicina: kol,
            status: "Ceka",
            datum: dnow(),
            mats: vm,
            struktura: vm,
            res: pon.res || pon.rezultat || null,
            nap: pon.nap || pon.napomena || "",
            izvor: "ponuda",
            template_id: linkedBase.template_id,
            product_template_id: linkedBase.product_template_id,
            product_template: templatePayload,
            template: templatePayload,
            kalkulacija_payload: kalkulacijaPayload,
            ponuda_payload: linkedBase.ponuda_payload,
            order_data: linkedBase.order_data,
            source_chain: linkedBase.source_chain,
            source_status: linkedBase.source_status,
            product_master_id: linkedBase.product_master_id,
            template_version: linkedBase.template_version,
            template_locked: linkedBase.template_locked,
            operacije_iz_template: linkedBase.operacije_iz_template
        };

        // Spreči dupliranje naloga za istu ponudu/broj.
        try {
            var lokalniPostojeci = [];
            try { lokalniPostojeci = JSON.parse(window.localStorage.getItem("maropack_nalozi_trajno") || "[]"); } catch (e) { lokalniPostojeci = []; }
            if (lokalniPostojeci.some(function (x) { return String(x.ponBr || x.broj_naloga || x.broj) === String(broj); })) {
                msg("Nalozi za ovu ponudu već postoje lokalno. Otvaram pregled naloga.");
                setPage("nalozi");
                setPregPonuda(null);
                return;
            }

            const { data: postojeci, error: checkError } = await supabase
                .from('nalozi')
                .select('id, ponBr, broj_naloga')
                .or('ponBr.eq.' + broj + ',broj_naloga.eq.' + broj + ',broj.eq.' + broj);
            if (checkError) throw checkError;
            if (postojeci && postojeci.length > 0) {
                msg("Nalozi za ovu ponudu već postoje. Otvaram pregled naloga.");
                setPage("nalozi");
                setPregPonuda(null);
                return;
            }
        } catch (e) {
            console.warn("Provera duplikata nije uspela, nastavljam kreiranje:", e.message);
        }

        var tipovi = [];
        tipovi.push({ tip: "materijal", naziv: "Nalog za potrebu materijala", ik: "box", boj: "#f59e0b" });

        if (tipProizvoda === "kesa") {
            tipovi.push({ tip: "kasiranje", naziv: "Nalog za kaširanje", ik: "link", boj: "#1d4ed8" });
            tipovi.push({ tip: "kesa", naziv: "Nalog za kesu", ik: "bag", boj: "#b91c1c" });
        } else if (tipProizvoda === "spulna") {
            tipovi.push({ tip: "formatiranje", naziv: "Nalog za formatiranje", ik: "roll", boj: "#7c3aed" });
            tipovi.push({ tip: "spulna", naziv: "Nalog za špulnu", ik: "roll", boj: "#059669" });
        } else {
            tipovi.push({ tip: "stampa", naziv: "Nalog za štampu", ik: "print", boj: "#3b82f6" });
            tipovi.push({ tip: "kasiranje", naziv: "Nalog za kaširanje", ik: "link", boj: "#1d4ed8" });
            tipovi.push({ tip: "perforacija_rezanje", naziv: "Nalog za perforaciju i rezanje", ik: "cut", boj: "#6366f1" });
        }

        var qrCodeBase64 = null;
        try {
            qrCodeBase64 = await QRCode.toDataURL(JSON.stringify({ broj_naloga: broj, ponuda_id: pon.id || null, tip: tipProizvoda, kupac: kupac, proizvod: nazivProizvoda }), { errorCorrectionLevel: 'M', type: 'image/png', width: 260, margin: 2 });
        } catch (e) { console.warn("QR nije kreiran:", e.message); }

        var novi = tipovi.map(function (t) {
            var linked = buildOrderSourcePack({ ponuda: pon, tipOperacije: t.tip, tipProizvoda: tipProizvoda });
            return {
                // NOVI STANDARD
                broj_naloga: broj,
                ponBr: broj,
                ponId: pon.id || pon.ponId || null,
                ponuda_id: pon.id || pon.ponuda_id || null,
                master_nalog_id: masterId,
                master_broj: broj,
                master_nalog: masterNalog,
                kalkulacija_id: pon.kalkulacija_id || pon.kalkulacije_id || null,
                tip: tipProizvoda,
                tip_proizvoda: tipProizvoda,
                tip_naloga: t.tip,
                vrsta: t.tip,
                operacija: t.naziv,
                naziv: t.naziv,
                ik: t.ik,
                boj: t.boj,
                status: "Ceka",
                datum: dnow(),
                kupac: kupac,
                prod: nazivProizvoda,
                proizvod: nazivProizvoda,
                kol: kol,
                kolicina: kol,
                mats: vm,
                struktura: vm,
                res: pon.res || pon.rezultat || null,
                specifikacija: pon.specifikacija || pon.struktura || vm,
                template_id: linked.template_id,
                product_template_id: linked.product_template_id,
                product_template: linked.product_template,
                template: linked.product_template,
                templateData: linked.templateData,
                kalkulacija_payload: linked.kalkulacija_payload,
                ponuda_payload: linked.ponuda_payload,
                order_data: linked.order_data,
                source_chain: linked.source_chain,
                source_status: linked.source_status,
                product_master_id: linked.product_master_id,
                template_version: linked.template_version,
                template_locked: linked.template_locked,
                operacije_iz_template: linked.operacije_iz_template,
                qr_kod: qrCodeBase64,
                radnik: "",
                nap: pon.nap || pon.napomena || "",
                redni_broj: t.redni_broj || null
            };
        });

        try {
            try {
                await supabase.from('master_nalozi').insert([masterNalog]);
            } catch (masterErr) {
                console.warn("Master nalog tabela nije dostupna ili RLS blokira upis, nastavljam preko nalozi/localStorage:", masterErr.message);
            }
            const { error: e1 } = await supabase.from('nalozi').insert(novi.map(toNalogRow));
            if (e1) throw e1;
            if (pon.id) {
                await supabase.from('ponude').update({ status: "prihvaceno" }).eq('id', pon.id);
            }
            setDb(function (old) {
                var stari = old && old.nalozi ? old.nalozi : [];
                return Object.assign({}, old, { nalozi: [].concat(novi, stari), master_nalozi: [masterNalog].concat((old && old.master_nalozi) || []) });
            });
            msg("Kreirano " + novi.length + " profesionalnih naloga za " + tipProizvoda + "! Br: " + broj);
            setPage("nalozi");
            setPregPonuda(null);
        } catch (e) {
            // Fallback za lokalni rad bez podešenog Supabase-a/RLS-a: nalozi se ne gube.
            try {
                var lokalni = JSON.parse(window.localStorage.getItem("maropack_nalozi_trajno") || "[]");
                var noviSaId = novi.map(function (n, i) {
                    return Object.assign({ id: "LOCAL-" + broj + "-" + (i + 1) }, n, { local_only: true });
                });
                window.localStorage.setItem("maropack_nalozi_trajno", JSON.stringify(noviSaId.concat(lokalni)));
                var lokalniMasteri = [];
                try { lokalniMasteri = JSON.parse(window.localStorage.getItem("maropack_master_nalozi") || "[]"); } catch (e2) { lokalniMasteri = []; }
                window.localStorage.setItem("maropack_master_nalozi", JSON.stringify([masterNalog].concat(lokalniMasteri)));
                setDb(function (old) {
                    var stari = old && old.nalozi ? old.nalozi : [];
                    return Object.assign({}, old, { nalozi: [].concat(noviSaId, stari), master_nalozi: [masterNalog].concat((old && old.master_nalozi) || []) });
                });
                msg("Supabase nije prihvatio upis, ali nalozi su sačuvani lokalno za test. Br: " + broj, "ok");
                setPage("nalozi");
                setPregPonuda(null);
            } catch (localErr) {
                msg("Greška kreiranja naloga: " + e.message, "err");
            }
        }
    }

    var inp = { width: "100%", padding: "9px 12px", borderRadius: 8, border: "1px solid #e2e8f0", fontSize: 13, color: "#1e293b", background: "#f8fafc", outline: "none", boxSizing: "border-box" };
    var card = { background: "#fff", borderRadius: 12, padding: 20, boxShadow: "0 1px 3px rgba(0,0,0,0.04)", border: "1px solid #e8edf3" };
    var lbl = { fontSize: 10, fontWeight: 700, color: "#64748b", textTransform: "uppercase", letterSpacing: 0.6, marginBottom: 4, display: "block" };
    var SBJ = { "Ceka": "#f59e0b", "U toku": "#3b82f6", "Završeno": "#10b981", "Ceka_bg": "#fffbeb", "U toku_bg": "#eff6ff", "Završeno_bg": "#f0fdf4" };
    // [build v51] Jake boje statusa — pun gradijent, bela slova, čitljivo iz aviona.
    function statusStil(st) {
        var s = String(st || "").toLowerCase();
        if (s.indexOf("zavr") === 0 || s === "zavrseno") return { grad: "linear-gradient(135deg,#16a34a,#15803d)", traka: "#16a34a", bg: "#f4fdf6", tekst: "ZAVRŠENO ✓" };
        // poslato_stampariji — nalog radi eksterna štamparija (Milinković / Topolastika)
        if (s.indexOf("poslato") === 0) return { grad: "linear-gradient(135deg,#7c3aed,#6d28d9)", traka: "#7c3aed", bg: "#faf7ff", tekst: "U ŠTAMPARIJI" };
        if (s.indexOf("radi") === 0 || s.indexOf("u toku") === 0 || s.indexOf("u_toku") === 0 || s.indexOf("u proizvodnji") === 0) return { grad: "linear-gradient(135deg,#3b82f6,#2563eb)", traka: "#3b82f6", bg: "#f8fbff", tekst: "U TOKU" };
        if (s.indexOf("sprem") === 0) return { grad: "linear-gradient(135deg,#10b981,#059669)", traka: "#10b981", bg: "#f6fefb", tekst: "SPREMNO" };
        if (s.indexOf("zastoj") === 0 || s.indexOf("pauz") === 0) return { grad: "linear-gradient(135deg,#dc2626,#b91c1c)", traka: "#dc2626", bg: "#fef2f2", tekst: "ZASTOJ" };
        return { grad: "linear-gradient(135deg,#f59e0b,#d97706)", traka: "#f59e0b", bg: "#fffdf7", tekst: "ČEKA" };
    }
    var ICONS = { "box": "📦", "print": "🖨️", "link": "🔗", "cut": "✂️", "circle": "🔵", "star": "✨", "bag": "🛍️", "image": "📐", "roll": "🎞️" };
    var TIP_BOJA = { "folija": "#1d4ed8", "kesa": "#059669", "spulna": "#7c3aed" };
    var TIP_LAB = { "folija": "Folija", "kesa": "Kesa", "spulna": "Špulna" };


    // Print je sada unutar PregledNalogaPRO / NalogLayoutPRO, da svi nalozi imaju isti profesionalni izgled.

    // ✅ LOGIN JE PREBAČEN U AuthProvider - ovaj blok se briše

    // ✅ FINAL CLEAN ACCORDION NAVIGATION STRUCTURE
    // Navigacija je izdvojena u src/config/navigation.js da App.jsx ne drži meni u sebi.
    const { lang } = useLang();
    const navGroupsAll = getNavGroups(isAdmin, userProfile?.uloga, lang);
    // ── BOJA PO GRUPI (v: meni "3") ─────────────────────────────────────────────
    // Svaka grupa ima svoju boju: leva traka na headeru + akcenat aktivne stavke.
    // Pogodak po ključu ILI po tekstu labele (case-insensitive) — otporno na to
    // kako su grupe nazvane u navigation.js. Bez pogotka → neutralna plava.
    const GRUPA_BOJE = [
        [/dash|pocetna|početna|home/i, "#6366f1"],
        [/kalk|calcul/i, "#f59e0b"],
        [/baza|proizvod|templ|product/i, "#10b981"],
        [/proizvodn|production|mes|pogon/i, "#ef4444"],
        [/magac|zalih|warehouse|stock/i, "#0ea5e9"],
        [/ai|asisten|agent/i, "#a855f7"],
        [/sistem|system|podeš|settings|admin/i, "#64748b"],
        [/izvest|izvešt|report|analit/i, "#0891b2"],
        [/ponud|offer|prodaj/i, "#e11d48"],
    ];
    function bojaGrupe(g) { return "#3b82f6"; } // jedinstven akcenat — bez šarenila

    // Magacioneri sa ulogom "radnik" (magacin2, magacin3) vide SAMO Magacin modul.
    const samoMagacinRola = userProfile?.uloga === "radnik";
    const navGroups = samoMagacinRola
        ? navGroupsAll
            .map(function (g) { return { ...g, items: (g.items || []).filter(function (it) { return it.k === "rolne_engine"; }) }; })
            .filter(function (g) { return (g.items || []).length > 0; })
        : navGroupsAll;
    const mobileMagacionerMode = (isMagacioner || samoMagacinRola) && isMobileViewport;
    // Puna aplikacija NA TELEFONU je privilegija: admin i manager uvek, ostalima je
    // admin uključuje kolonom telefon_pun_pristup (boolean) u profilu korisnika.
    // Magacioneri ovim NISU dirnuti — oni i dalje imaju svoj mobilni magacinski ekran.
    const punaAppNaTelefonu = isAdmin || userProfile?.uloga === "manager" || userProfile?.telefon_pun_pristup === true;

    function toggleGroup(groupKey) {
        if (openGroups.includes(groupKey)) {
            setOpenGroups(openGroups.filter(k => k !== groupKey));
        } else {
            setOpenGroups([...openGroups, groupKey]);
        }
    }

    async function handleLogout() {
        await signOut();
        window.location.href = '/';
    }

    return (
        <div style={{ minHeight: "100vh", background: "#f1f5f9", fontFamily: "'Segoe UI',system-ui,sans-serif", color: "#1e293b", display: "flex", alignItems: "stretch" }}>
            {notif && <Notif msg={notif.msg} tip={notif.tip} />}
            {stampa && <PrintA4 data={stampa} onClose={function () { setStampa(null); }} />}

            {/* ── MOBILNI REŽIM ─────────────────────────────────────────────────
                Jedan globalni sloj koji celu aplikaciju čini upotrebljivom na telefonu:
                - sidebar postaje fioka sa hamburger dugmetom (☰)
                - sve inline grid mreže se preslažu u uske kolone (auto-fit, !important
                  pobedjuje inline stil — jedino tako bez diranja 50+ modula)
                - tabele klize prstom umesto da se gnječe
                - inputi 16px da iOS ne zumira pri fokusu                       */}
            {/* zabrana Chrome auto-dark inverzije za CELU aplikaciju (i magacionere) */}
            <style>{`:root{ color-scheme: only light; }`}</style>
            {!mobileMagacionerMode && <style>{`
                /* Sidebar: čvrsta pravila nezavisna od inline stilova — meni uvek isti izgled */
                .mp-sidebar{ background:#0f1b33 !important; }
                .mp-sidebar nav, .mp-sidebar nav *{ background-color: transparent; }
                .mp-sidebar .mp-grp{ background:#22345a !important; }
                .mp-sidebar .mp-grp-active{ background:#22345a !important; }
                .mp-sidebar .mp-item-active{ background:#2563eb !important; }
                /* NE seći nazive — dozvoli prelom u dva reda umesto "…" */
                .mp-sidebar .mp-label{ white-space: normal; overflow: visible; text-overflow: clip; line-height: 1.2; }
                /* JEZIK blok: navy podloga (sama komponenta je već sređena u LanguageProvider) */
                .mp-lang{ background:#0f1b33 !important; border:none !important; box-shadow:none !important; }
                @media (max-width: 767px){
                    /* VAŽI SAMO ZA SADRŽAJ (.mp-sadrzaj) — nikad za sidebar/meni */
                    .mp-sadrzaj [style*="grid-template-columns"]{ grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)) !important; }
                    .mp-sadrzaj div:has(> table){ overflow-x: auto; -webkit-overflow-scrolling: touch; }
                    .mp-sadrzaj table{ min-width: 560px; }
                    .mp-sadrzaj input, .mp-sadrzaj select, .mp-sadrzaj textarea{ font-size: 16px !important; }
                    body{ -webkit-text-size-adjust: 100%; }
                }
            `}</style>}
            {isMobileViewport && !mobileMagacionerMode && punaAppNaTelefonu && (
                <button onClick={function () { setNavOtvoren(!navOtvoren); }}
                    style={{ position: "fixed", top: 12, left: 12, zIndex: 1300, width: 44, height: 44, borderRadius: 12, border: "none", background: "#0f172a", color: "#fff", fontSize: 20, fontWeight: 900, cursor: "pointer", boxShadow: "0 6px 18px rgba(15,23,42,.35)" }}>
                    {navOtvoren ? "✕" : "☰"}
                </button>
            )}
            {isMobileViewport && navOtvoren && (
                <div onClick={function () { setNavOtvoren(false); }}
                    style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,.55)", zIndex: 1100 }} />
            )}

            {/* ACCORDION SIDEBAR */}
            <div className="mp-sidebar" style={{
                width: 256, background: "#0f1b33", display: mobileMagacionerMode ? "none" : "flex",
                flexDirection: "column", flexShrink: 0, minHeight: "100vh", alignSelf: "stretch", borderRight: "1px solid #1a2a49",
                ...(isMobileViewport ? { position: "fixed", top: 0, bottom: 0, left: navOtvoren ? 0 : -260, zIndex: 1200, transition: "left .22s ease", overflowY: "auto", boxShadow: navOtvoren ? "0 0 44px rgba(0,0,0,.5)" : "none" } : {})
            }}>
                <div style={{ padding: "16px 16px 10px", textAlign: "center", background: "#0f1b33" }}>
                    <div style={{ background: "#ffffff", borderRadius: 9, padding: "5px 12px", display: "inline-block", boxShadow: "0 2px 10px rgba(0,0,0,.35)" }}>
                        <img src={LOGO_B64} alt="Maropack" style={{ height: 26, objectFit: "contain", display: "block" }} />
                    </div>
                </div>

                {/* PREKIDAČ JEZIKA (SR / EN / DE) */}
                <div className="mp-lang" style={{ padding: "10px 10px 4px" }}>
                    <LanguageSwitcher />
                </div>

                <nav style={{ padding: "8px 8px", flex: 1, overflowY: "auto", background: "#0f1b33" }}>
                    {navGroups.map(function (group) {
                        const isOpen = openGroups.includes(group.key);
                        const hasActivePage = group.items.some(item => item.k === page);
                        const gBoja = bojaGrupe(group);

                        return (
                            <div key={group.key} style={{ marginBottom: 6 }}>
                                {/* GROUP HEADER */}
                                <div
                                    onClick={function () { toggleGroup(group.key); }}
                                    className={hasActivePage ? "mp-grp mp-grp-active" : "mp-grp"}
                                    style={{
                                        padding: "10px 12px",
                                        background: "#22345a",
                                        borderRadius: 11,
                                        borderLeft: (hasActivePage ? "4px" : "0px") + " solid #3b82f6",
                                        cursor: "pointer",
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "space-between",
                                        transition: "all 0.18s",
                                        marginBottom: isOpen ? 4 : 7
                                    }}
                                    onMouseEnter={function (e) {
                                        if (!hasActivePage) e.currentTarget.style.background = "#2b4068";
                                    }}
                                    onMouseLeave={function (e) {
                                        if (!hasActivePage) e.currentTarget.style.background = "#22345a";
                                    }}
                                >
                                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                        <span style={{ fontSize: 16 }}>{group.icon}</span>
                                        <span className="mp-label" style={{ fontSize: 13.5, fontWeight: hasActivePage ? 900 : 800, color: "#ffffff", letterSpacing: 0.2 }}>
                                            {group.label}
                                        </span>
                                    </div>
                                    <span style={{
                                        fontSize: 12,
                                        color: "#e2e8f0",
                                        transform: isOpen ? "rotate(90deg)" : "rotate(0deg)",
                                        transition: "transform 0.2s"
                                    }}>
                                        ▶
                                    </span>
                                </div>

                                {/* GROUP ITEMS */}
                                <div style={{
                                    maxHeight: isOpen ? (group.items.length * 44 + 24) + "px" : "0px",
                                    overflow: "hidden",
                                    transition: "max-height 0.3s ease",
                                    paddingLeft: 28
                                }}>
                                    {group.items.map(function (item) {
                                        const isActive = page === item.k;
                                        return (
                                            <div
                                                key={item.k}
                                                className={isActive ? "mp-item-active" : ""}
                                                onClick={function () { setPage(item.k); setNavOtvoren(false); }}
                                                style={{
                                                    padding: "9px 12px",
                                                    fontSize: 13.5,
                                                    borderRadius: 6,
                                                    margin: "2px 0",
                                                    cursor: "pointer",
                                                    color: "#ffffff",
                                                    background: isActive ? "#2563eb" : "transparent",
                                                    borderLeft: "3px solid " + (isActive ? "#93c5fd" : "transparent"),
                                                    fontWeight: isActive ? 800 : 700,
                                                    display: "flex",
                                                    alignItems: "center",
                                                    gap: 8,
                                                    transition: "all 0.18s"
                                                }}
                                                onMouseEnter={function (e) {
                                                    if (!isActive) {
                                                        e.currentTarget.style.background = "#22345a";
                                                        e.currentTarget.style.color = "#ffffff";
                                                    }
                                                }}
                                                onMouseLeave={function (e) {
                                                    if (!isActive) {
                                                        e.currentTarget.style.background = "transparent";
                                                        e.currentTarget.style.color = "#c7d2e5";
                                                    }
                                                }}
                                            >
                                                <span style={{ fontSize: 14, flexShrink: 0 }}>{item.i}</span>
                                                <span className="mp-label">{item.l}</span>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        );
                    })}
                </nav>

                {/* USER INFO - NA KRAJU SIDEBARA */}
                <div style={{
                    padding: 16,
                    borderTop: "1px solid #1e293b",
                    background: "#020617"
                }}>
                    <div style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 10,
                        marginBottom: 10
                    }}>
                        <div style={{
                            width: 36,
                            height: 36,
                            borderRadius: "50%",
                            background: "linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            fontSize: 16,
                            fontWeight: 700,
                            color: "white"
                        }}>
                            {(userProfile?.ime || user?.email || "U")[0].toUpperCase()}
                        </div>
                        <div style={{ flex: 1, minWidth: 0 }}>
                            <div style={{
                                fontSize: 13,
                                fontWeight: 600,
                                color: "white",
                                overflow: "hidden",
                                textOverflow: "ellipsis",
                                whiteSpace: "nowrap"
                            }}>
                                {userProfile?.ime || user?.email?.split('@')[0] || "User"}
                            </div>
                            <div style={{ fontSize: 11, color: "#64748b" }}>
                                {userProfile?.uloga === 'admin' ? '👑 Admin' :
                                    userProfile?.uloga === 'manager' ? '⭐ Manager' :
                                        userProfile?.uloga === 'magacioner' ? '🏪 Magacioner' : '👷 User'}
                            </div>
                        </div>
                    </div>
                    <button
                        onClick={async function () {
                            if (window.confirm('Da li želite da se odjavite?')) {
                                await signOut();
                            }
                        }}
                        style={{
                            width: "100%",
                            padding: "8px",
                            background: "#1e293b",
                            color: "#94a3b8",
                            border: "none",
                            borderRadius: 6,
                            fontSize: 12,
                            cursor: "pointer",
                            transition: "all 0.2s",
                            fontWeight: 600
                        }}
                        onMouseEnter={function (e) {
                            e.currentTarget.style.background = "#dc2626";
                            e.currentTarget.style.color = "white";
                        }}
                        onMouseLeave={function (e) {
                            e.currentTarget.style.background = "#1e293b";
                            e.currentTarget.style.color = "#94a3b8";
                        }}
                    >
                        🚪 Odjavi se
                    </button>
                </div>
            </div>

            {/* SADRZAJ */}
            {isMobileViewport && !mobileMagacionerMode && !punaAppNaTelefonu ? (
                <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
                    <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 18, padding: "28px 22px", maxWidth: 380, textAlign: "center", boxShadow: "0 10px 30px rgba(15,23,42,.08)" }}>
                        <div style={{ fontSize: 40 }}>📵</div>
                        <div style={{ fontWeight: 950, fontSize: 17, margin: "10px 0 6px" }}>Puna aplikacija nije omogućena na telefonu</div>
                        <div style={{ color: "#64748b", fontSize: 13.5, lineHeight: 1.5 }}>
                            Tvoj nalog može da koristi MAROPACK sa računara. Za rad za mašinom skeniraj QR kod sa papirnog naloga.
                            Administrator može da ti omogući pristup sa telefona.
                        </div>
                        <button onClick={handleLogout} style={{ marginTop: 16, border: "none", background: "#0f172a", color: "#fff", borderRadius: 12, padding: "11px 20px", fontWeight: 900, cursor: "pointer" }}>Odjavi se</button>
                    </div>
                </div>
            ) : (
                <div className="mp-sadrzaj" style={{ flex: 1, overflow: "auto", padding: mobileMagacionerMode ? 0 : (isMobileViewport ? "64px 10px 28px" : 22), minWidth: 0 }}>

                    {/* DASHBOARD */}
                    {(page === "dash" || page === "dashboard") && <DashboardPRO setPage={setPage} />}

                    {/* KALKULATORI */}
                    {page === "kalk_folija" && <KalkulacijaFolije />}

                    {/* LISTA KALKULACIJA */}
                    {page === "kalkulacije_lista" && (
                        <ListaKalkulacija
                            setPage={setPage}
                            onOtvoriKalkulaciju={(kal) => {
                                // Otvori odgovarajuću stranicu zavisno od tipa
                                if (kal.tip === 'folija') {
                                    setPage('kalk_folija');
                                    // Sačuvaj kalkulaciju u localStorage za učitavanje
                                    localStorage.setItem('editKalkulacija', JSON.stringify(kal));
                                } else if (kal.tip === 'kesa') {
                                    setPage('kalk_kesa');
                                    localStorage.setItem('editKalkulacija', JSON.stringify(kal));
                                } else if (kal.tip === 'spulna') {
                                    setPage('kalk_spulna');
                                    localStorage.setItem('editKalkulacija', JSON.stringify(kal));
                                }
                            }}
                            onKreirajPonudu={async (kal) => {
                                console.log('🚀 Kreiram ponudu iz:', kal);
                                try {
                                    const result = await kreirajPonuduIzKalkulacije(kal);
                                    console.log('📊 Rezultat:', result);

                                    if (result.success) {
                                        msg('Ponuda kreirana iz kalkulacije!');
                                        setPage('ponude');
                                    } else {
                                        console.error('❌ Greška:', result.error);
                                        msg('Greška pri kreiranju ponude: ' + result.error, 'err');
                                    }
                                } catch (err) {
                                    console.error('💥 Exception:', err);
                                    msg('Greška: ' + err.message, 'err');
                                }
                            }}
                        />
                    )}

                    {/* KALKULACIJA KESE */}
                    {page === "kalk_kesa" && (
                        <KalkulacijaKese setPage={setPage} />
                    )}
                    {/* KALKULACIJA ŠPULNE */}
                    {page === "kalk_spulna" && (
                        <KalkulacijaSpulne setPage={setPage} />
                    )}

                    {/* PONUDE - ZAMENJENO: render PonudePRO sa handlerima */}
                    {page === "ponude" && (

                        <PonudePRO

                            onPrihvati={kreirajNalogeIzPonude}

                            onOtvoriKalkulaciju={(kal) => {

                                if (kal.tip === 'folija') {

                                    setPage('kalk_folija');

                                    localStorage.setItem(
                                        'editKalkulacija',
                                        JSON.stringify(kal)
                                    );

                                } else if (kal.tip === 'kesa') {

                                    setPage('kalk_kesa');

                                    localStorage.setItem(
                                        'editKalkulacija',
                                        JSON.stringify(kal)
                                    );

                                } else if (kal.tip === 'spulna') {

                                    setPage('kalk_spulna');

                                    localStorage.setItem(
                                        'editKalkulacija',
                                        JSON.stringify(kal)
                                    );
                                }
                            }}
                        />
                    )}



                    {page === "plan_proizvodnje" && (
                        <MachineSchedulerPRO db={db} msg={msg} />
                    )}

                    {page === "live_production" && (
                        <LiveProductionMES db={db} msg={msg} />
                    )}


                    {page === "quality_control" && (
                        <QualityControlPRO db={db} msg={msg} />
                    )}

                    {page === "tehnicki_list" && (
                        <TehnickiListPRO db={db} msg={msg} />
                    )}


                    {page === "rolne_engine" && (
                        <RolneWarehouseEngine db={db} setDb={setDb} msg={msg} forceMobile={(isMagacioner || userProfile?.uloga === "radnik") && isMobileViewport} />
                    )}

                    {page === "kalkulator_maticnih" && (
                        <KalkulatorMaticnihRolni db={db} msg={msg} />
                    )}

                    {page === "planer_rezanja_magacin" && (
                        <PlanerRezanjaIzMagacina db={db} setDb={setDb} msg={msg} />
                    )}

                    {page === "formatiranje_rolni" && (
                        <FormatiranjeRolniPRO msg={msg} />
                    )}

                    {page === "formatiranje_po_potrebi" && (
                        <FormatiranjePoPotrebi msg={msg} />
                    )}

                    {/* RADNI NALOZI */}
                    {page === "nalozi" && (
                        <div>
                            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }}>
                                <h2 style={{ margin: 0, fontSize: 20, fontWeight: 800 }}>🏭 Glavni nalozi</h2>
                                <div style={{ fontSize: 13, color: "#64748b" }}>{db.nalozi.filter(function (n) { var s = String(n.status || "").toLowerCase(); return s.indexOf("zavr") !== 0 && s !== "zavrseno"; }).length} otvorenih / {db.nalozi.length} ukupno</div>
                            </div>
                            {pregNalog ? (
                                <PregledNalogaPRO
                                    brojNaloga={pregNalog.ponBr || pregNalog.broj_naloga || pregNalog.broj}
                                    osnovniNalog={pregNalog}
                                    naloziProp={db.nalozi}
                                    nalozi={db.nalozi}
                                    onBack={function () { setPregNalog(null); }}
                                />
                            ) : db.nalozi.length === 0 ? (
                                <div style={Object.assign({}, card, { textAlign: "center", padding: 50, color: "#94a3b8" })}>
                                    <div style={{ fontSize: 36, marginBottom: 10 }}>🔧</div>
                                    <div>Nema naloga. Odobrite ponudu da kreirate naloge.</div>
                                </div>
                            ) : (
                                <div>
                                    {(function () {
                                        var grupe = {};
                                        db.nalozi.forEach(function (n) { var key = n.glavni_nalog_id || n.master_nalog_id || n.ponBr || n.broj_naloga || n.broj || "Bez broja"; if (!grupe[key]) grupe[key] = []; grupe[key].push(n); });
                                        return Object.keys(grupe).map(function (key) {
                                            var gr = grupe[key].slice().sort(function (a, b) { return (a.redosled || 0) - (b.redosled || 0); });
                                            var master = (db.master_nalozi || []).find(function (m) { return String(m.id) === String(key); });
                                            var br = (master && (master.broj_naloga || master.broj)) || gr[0].master_broj || gr[0].ponBr || gr[0].broj_naloga || key;
                                            var grKupac = (master && (master.kupac || master.klijent)) || gr[0].kupac || gr[0].klijent;
                                            var grProizvod = (master && (master.proizvod || master.naziv)) || gr[0].prod || gr[0].proizvod || gr[0].naziv;
                                            var zav = gr.filter(function (n) { return n.status === "Završeno" || n.status === "zavrseno"; }).length;
                                            var pct = gr.length > 0 ? (zav / gr.length) * 100 : 0;
                                            var tipNaloga = normalizujTipProizvoda((master && (master.tip || master.tip_proizvoda)) || gr[0].tip || gr[0].tip_proizvoda || "folija");
                                            return (
                                                <div key={key} style={Object.assign({}, card, { marginBottom: 18, padding: 22 })}>
                                                    <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12, paddingBottom: 10, borderBottom: "1px solid #f1f5f9", flexWrap: "wrap" }}>
                                                        <span style={{ fontWeight: 800, fontSize: 14, color: "#1d4ed8" }}>{br || 'N/A'}</span>
                                                        <span style={{ background: (TIP_BOJA[tipNaloga] || "#64748b") + "20", color: TIP_BOJA[tipNaloga] || "#64748b", borderRadius: 6, padding: "2px 8px", fontWeight: 700, fontSize: 10 }}>{TIP_LAB[tipNaloga] || "—"}</span>
                                                        <span style={{ fontWeight: 600, fontSize: 13 }}>{grKupac}</span>
                                                        <span style={{ color: "#64748b", fontSize: 12 }}>{grProizvod}</span>
                                                        <span style={{ marginLeft: "auto", fontSize: 12, color: "#64748b" }}>{zav}/{gr.length} završeno</span>
                                                        <div style={{ width: 80, height: 6, background: "#f1f5f9", borderRadius: 3, overflow: "hidden" }}>
                                                            <div style={{ height: "100%", background: "#10b981", borderRadius: 3, width: pct + "%" }} />
                                                        </div>
                                                    </div>
                                                    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(280px,1fr))", gap: 16 }}>
                                                        {gr.map(function (n) {
                                                            return (
                                                                <div key={n.id} onClick={function () { setPregNalog(n); }} style={{ background: statusStil(n.status).bg, border: "1px solid #e2e8f0", borderLeft: "6px solid " + statusStil(n.status).traka, borderRadius: 14, padding: "16px 18px", cursor: "pointer" }}>
                                                                    <div style={{ display: "flex", alignItems: "center", gap: 9, marginBottom: 11 }}>
                                                                        <span style={{ fontSize: 19 }}>{ICONS[n.ik]}</span>
                                                                        <span style={{ fontWeight: 800, fontSize: 15 }}>{n.naziv}</span>
                                                                    </div>
                                                                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
                                                                        <span style={{ background: statusStil(n.status).grad, color: "#fff", borderRadius: 999, padding: "5px 11px 5px 9px", fontWeight: 900, fontSize: 11, display: "inline-flex", alignItems: "center", gap: 5, boxShadow: "0 2px 5px rgba(0,0,0,.12)" }}>
                                                                            <span style={{ width: 7, height: 7, borderRadius: "50%", background: "rgba(255,255,255,.9)" }} />
                                                                            {statusStil(n.status).tekst}
                                                                        </span>
                                                                        {n.radnik && <span style={{ fontSize: 13, color: "#334155", fontWeight: 700 }}>👤 {n.radnik}</span>}
                                                                    </div>
                                                                    <div style={{ marginTop: 8, fontSize: 10, color: "#64748b", fontWeight: 700 }}>Klikni za PRO pregled / štampu</div>
                                                                </div>
                                                            );
                                                        })}
                                                    </div>
                                                </div>
                                            );
                                        });
                                    })()}
                                </div>
                            )}
                        </div>
                    )}



                    {/* Profesionalni nalozi se prikazuju samo kroz PregledNalogaPRO. */}

                    {/* BAZA / TEMPLATE MODULI */}
                    {page === "baza_proizvoda_pro" && (<ProductMasterPRO db={db} setDb={setDb} setPage={setPage} msg={msg} />)}
                    {page === "lista_proizvoda_kupci" && (<ListaProizvodaKupci msg={msg} />)}
                    {page === "template_engine" && (<ProductTemplateEngineV20 db={db} setDb={setDb} msg={msg} setPage={setPage} />)}
                    {page === "uvoz_spulna_excel" && (<UvozSpulnaExcel onGotovo={() => { if (typeof msg === "function") msg("Špulne uvezene u bazu proizvoda."); }} />)}

                    {/* ✅ NOVO: AUDIT LOG */}
                    {page === "audit_log" && isAdmin && <AuditLog />}
                    {page === "user_management" && isAdmin && <UserManagement />}

                    {/* MAGACIN UNIFIED - SVE U JEDNOM */}
                    {page === "analiza_materijal_stavke" && (<AnalizaMaterijalStavke msg={msg} />)}

                    {/* ✅ DRUGI PRO MODULI */}
                    {page === "dashboard_pro" && <DashboardPRO setPage={setPage} />}
                    {page === "manager_dashboard" && <ManagerDashboard />}
                    {page === "finansije_kpi" && <FinansijeKPI_PRO db={db} msg={msg} />}
                    {page === "mobile" && <MobileApp setPage={setPage} />}

                    {/* 🤖 AI MODULI */}
                    {page === "ai_planner" && <AIProductionPlanner setPage={setPage} />}
                    {page === "ai_chat" && <AIChatAssistant />}
                    {page === "ai_agent_command" && <AIAgentCommandCenter />}
                    {page === "ai_workflow" && <ProductAIWorkflow db={db} setDb={setDb} msg={msg} setPage={setPage} />}
                    {page === "ai_documents" && <DocumentAIWorkflow db={db} setDb={setDb} msg={msg} setPage={setPage} />}
                    {page === "ai_waste" && <AIWasteOptimizer />}
                    {page === "ai_quality" && <AIQualityInspector />}

                    {page === "system_stabilization" && <SystemStabilizationCenter db={db} msg={msg} />}
                    {page === "production_hardening" && <ProductionHardeningCenter db={db} msg={msg} />}
                    {page === "final_qa_deployment" && <FinalQADeploymentCenter db={db} msg={msg} />}
                    {page === "final_production_readiness" && <FinalProductionReadinessCenter db={db} msg={msg} />}
                    {page === "system_status" && <SystemStatusPRO db={db} />}
                    {page === "backup_security" && <BackupSecurityCenter db={db} />}

                    {page === "ai_kalk" && (
                        <AIAsistentKalkulacije
                            card={card}
                            inp={inp}
                            lbl={lbl}
                            msg={msg}
                        />
                    )}
                    {/* PODESAVANJA */}
                    {page === "pod" && isAdmin && (
                        <div>
                            <h2 style={{ margin: "0 0 18px", fontSize: 20, fontWeight: 800 }}>⚙️ Podešavanja</h2>
                            <div style={card}>
                                <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 14 }}>👥 Korisnici sistema</div>
                                <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
                                    <thead><tr style={{ borderBottom: "2px solid #e2e8f0" }}>
                                        {["Ime", "Uloga", "Lozinka"].map(function (h) { return <th key={h} style={{ padding: "8px", textAlign: "left", color: "#64748b", fontWeight: 600 }}>{h}</th>; })}
                                    </tr></thead>
                                    <tbody>
                                        {USERS.map(function (u) {
                                            return (
                                                <tr key={u.id} style={{ borderBottom: "1px solid #f1f5f9" }}>
                                                    <td style={{ padding: "10px 8px", fontWeight: 600 }}>{u.ime}</td>
                                                    <td style={{ padding: "10px 8px" }}><span style={{ background: u.uloga === "admin" ? "#fef3c7" : "#dbeafe", color: u.uloga === "admin" ? "#92400e" : "#1e40af", borderRadius: 6, padding: "2px 10px", fontWeight: 700, fontSize: 11 }}>{u.uloga === "admin" ? "Administrator" : u.uloga === "magacioner" ? "Magacioner" : u.uloga === "manager" ? "Manager" : "Radnik"}</span></td>
                                                    <td style={{ padding: "10px 8px", fontFamily: "monospace", color: "#94a3b8" }}>{u.pass}</td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}

                </div>
            )}

            {/* 🤖 GLOBALNO "Pitaj AI" — na SVAKOM ekranu (magacin, kalkulacije, templejti,
                nalozi, izveštaji...). Agent kroz svoje alate čita bazu, a kontekst mu kaže
                na kom je ekranu korisnik. Ekrani koji imaju svoj lokalni AIPomoc (bogatiji
                kontekst) automatski preuzimaju — dugme se nikad ne duplira. */}
            <AIPomoc
                ekran={(function () {
                    for (var gi = 0; gi < navGroupsAll.length; gi++) {
                        var its = navGroupsAll[gi].items || [];
                        for (var ii = 0; ii < its.length; ii++) if (its[ii].k === page) return its[ii].l;
                    }
                    return page;
                })()}
                kontekst={function () {
                    return {
                        naziv: "Ekran: " + page,
                        stranica: page,
                        naloga_u_bazi: (db.nalozi || []).length,
                        ponuda: (db.ponude || []).length,
                        proizvoda: (db.proizvodi || []).length,
                    };
                }}
            />
        </div>
    );
}


// ============================================
// AUTH WRAPPER (ROOT)
// ============================================
export default function App() {
    return (
        <LanguageProvider defaultLang="sr">
            <AuthProvider>
                <AppContent />
            </AuthProvider>
        </LanguageProvider>
    );
}

// ============================================
// AUTH ROUTER
// ============================================
function AppContent() {
    const { loading, user } = useAuth();

    // Loading state
    {
        const opidRani = new URLSearchParams(window.location.search).get("opid");
        if (opidRani) return <RadnikOperacija opid={opidRani} />;
    }

    if (loading) {
        return (
            <div style={{
                minHeight: "100vh",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background: "#f8fafc",
                flexDirection: "column"
            }}>
                <div style={{
                    width: 60,
                    height: 60,
                    border: "4px solid #e2e8f0",
                    borderTopColor: "#667eea",
                    borderRadius: "50%",
                    margin: "0 auto 20px",
                    animation: "spin 0.8s linear infinite"
                }} />
                <p style={{ color: "#64748b", fontWeight: 600, fontSize: 16 }}>
                    Učitavanje...
                </p>
                <style>{`
          @keyframes spin {
            to { transform: rotate(360deg); }
          }
        `}</style>
            </div>
        );
    }

    // Not logged in → show Login
    if (!user) {
        // IZUZETAK: QR sa papirnog naloga (?opid=<id operacije>).
        // Radnik za masinom skenira i odmah dobija START / PAUZA / ZAVRSENO —
        // bez kucanja emaila i sifre pored masine. Ko je radio se belezi tako sto
        // radnik upise svoje ime i prezime u samoj operaciji (kolona `radnik`).
        // SVESNA ODLUKA: ko dohvati papir moze da menja status TE operacije.
        // Ostatak aplikacije (magacin, cene, brisanje) ostaje iza logina.
        const opidBezLogina = new URLSearchParams(window.location.search).get("opid");
        if (opidBezLogina) return <RadnikOperacija opid={opidBezLogina} />;
        return <Login />;
    }

    // Logged in → show protected app
    return (
        <ProtectedRoute>
            <MainAppContent />
        </ProtectedRoute>
    );
}